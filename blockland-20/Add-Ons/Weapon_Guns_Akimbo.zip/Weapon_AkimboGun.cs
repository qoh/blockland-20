//akimbogun.cs

//we'll only get this far if we actually have the gun add-on
//  so it's safe to directly use stuff from that
//AddDamageType(<name>, <suicide message>, <kill message>, <vehicle damage scale>, <is direct damage>);
AddDamageType("AkimboGun",   '<bitmap:add-ons/Weapon_Guns_Akimbo/CI_2guns> %1',    '%2 <bitmap:add-ons/Weapon_Guns_Akimbo/CI_2guns> %1',0.05,1);
datablock ProjectileData(akimboGunProjectile)
{
   projectileShapeName = "add-ons/Weapon_Gun/bullet.dts";
   directDamage        = 30;
   directDamageType    = $DamageType::AkimboGun;
   radiusDamageType    = $DamageType::AkimboGun;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 0;
   verticalImpulse	  = 0;
   explosion           = gunExplosion;
   particleEmitter     = "";

   muzzleVelocity      = 90;
   velInheritFactor    = 1;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "Akimbo Gun Bullet";
};

//////////
// item //
//////////
datablock ItemData(AkimboGunItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "Add-Ons/Weapon_Gun/pistol.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Guns Akimbo";
	iconName = "./Icon_2guns";
	doColorShift = true;
	colorShiftColor = "0.1 0.1 0.2 1.000";

	 // Dynamic properties defined by the scripts
	image = AkimboGunImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(AkimboGunImage)
{
   // Basic Item properties
   shapeFile = "Add-Ons/Weapon_Gun/pistol.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = akimboGunProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = AkimboGunItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0] = "Activate";
	stateTransitionOnTimeout[0] = "Ready";
	stateTimeoutValue[0] = 0.2;
	stateSequence[0] = "ready";

	stateName[1] = "Ready";
	stateSequence[1] = "ready";
	stateTransitionOnTriggerDown[1] = "Fire";

	stateName[2] = "Fire";
	stateEjectShell[2]       = true;
	stateSequence[2] = "Fire";
	stateTransitionOnTimeout[2] = "Smoke";
   stateWaitForTimeout[2] = true;
	stateTimeoutValue[2] = 0.09;
	stateFire[2] = true;
	stateAllowImageChange[2] = false;
	stateScript[2] = "onFire";
	stateSound[2] = gunShot1Sound;
   stateEmitter[2]					= gunFlashEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";

   stateName[3] = "Smoke";
	stateEmitter[3]					= gunSmokeEmitter;
	stateEmitterTime[3]				= 0.05;
	stateEmitterNode[3]				= "muzzleNode";
	stateTimeoutValue[3]            = 0.01;
	stateTransitionOnTimeout[3]     = "Reload";

	stateName[4] = "Reload";
	stateAllowImageChange[4] = false;
	stateTransitionOnTriggerUp[4] = "FireAkimbo";
	stateSequence[4] = "ready";

	stateName[5] = "FireAkimbo";
	stateTimeoutValue[5] = 0.09;
	stateScript[5] = "onFireAkimbo";
	stateTransitionOnTimeOut[5] = "ready";
};


function AkimboGunImage::onFireAkimbo(%this,%obj,%slot)
{
   %obj.setImageTrigger(1,1);
}


datablock ShapeBaseImageData(LeftHandedGunImage)
{
   // Basic Item properties
   shapeFile = "Add-Ons/Weapon_Gun/pistol.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 1;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = akimboGunProjectile;
   projectileType = Projectile;

	casing = gunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = false;

   doColorShift = true;
   colorShiftColor = AkimboGunItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0] = "Activate";
	stateTransitionOnTimeout[0] = "Ready";
	stateTimeoutValue[0] = 0.2;
	stateSequence[0] = "ready";
   stateSound[0]		= weaponSwitchSound;

	stateName[1] = "Ready";
	stateSequence[1] = "ready";
	stateTransitionOnTriggerDown[1] = "Fire";

	stateName[2] = "Fire";
	stateEjectShell[2]       = true;
	stateSequence[2] = "Fire";
	stateTransitionOnTimeout[2] = "Smoke";
   stateWaitForTimeout[2] = true;
	stateTimeoutValue[2] = 0.09;
	stateFire[2] = true;
	stateAllowImageChange[2] = false;
	stateScript[2] = "onFire";
	stateSound[2] = gunShot1Sound;
   stateEmitter[2]					= gunFlashEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";

   stateName[3] = "Smoke";
	stateEmitter[3]					= gunSmokeEmitter;
	stateEmitterTime[3]				= 0.05;
	stateEmitterNode[3]				= "muzzleNode";
	stateTimeoutValue[3]            = 0.01;
	stateTransitionOnTimeout[3]     = "Reload";

	stateName[4] = "Reload";
	stateAllowImageChange[4] = false;
	stateTransitionOnTriggerUp[4] = "Ready";
	stateSequence[4] = "ready";


};

function LeftHandedGunImage::onFire(%this, %obj, %slot)
{
   Parent::onFire(%this,%obj,%slot);
   if(%obj.getDamagePercent() < 1.0)
		%obj.playThread(2, leftrecoil);
}

function AkimboGunImage::onMount(%this, %obj, %slot)
{
   Parent::onMount(%this, %obj, %slot);
   //mount lefthanded gun
   %obj.mountImage(LeftHandedGunImage, 1);
   //%obj.playThread(0, armreadyboth);
}
function AkimboGunImage::onUnMount(%this, %obj, %slot)
{
   Parent::onUnMount(%this, %obj, %slot);
   //unmount lefthanded gun
   %obj.unMountImage(1);
   //%obj.playThread(0, root);
}


function LeftHandedGunImage::onMount(%this, %obj, %slot)
{
   Parent::onMount(%this, %obj, %slot);
   %obj.playThread(1, armreadyboth);
}
function LeftHandedGunImage::onUnMount(%this, %obj, %slot)
{
   Parent::onUnMount(%this, %obj, %slot);
}

function AkimboGunImage::onFire(%this,%obj,%slot)
{
	if(%obj.getDamagePercent() < 1.0)
		%obj.playThread(2, shiftAway);
	Parent::onFire(%this,%obj,%slot);	

   //%obj.setImageTrigger(1,1);
}
