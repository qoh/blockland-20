//sport items, so you can do sports

//force require the skis since we use them for tumbling
%error = ForceRequiredAddOn("Item_Skis");

if(%error == $Error::AddOn_Disabled)
{
   //A bit of a hack:
   //  we just forced the skis to load, but the user had it disabled
   //  so lets make it so they can't select it
   SkiItem.uiName = "";
}

if(%error == $Error::AddOn_NotFound)
{
   //we don't have the jeep, so we're screwed
   error("ERROR: Item_Skis - required add-on Item_Skis not found");
}
else
{
	exec("./support.cs");
	exec("./basketball.cs");
	exec("./football.cs");
	exec("./soccer.cs");
	exec("./dodgeball.cs");
	exec("./horse.cs");
}

// debug crap
if( !$pref::server::isDebugCrap )
	return;
	
// exec my balls
function execBalls()
{
	exec( "Add-Ons/Item_Sports/server.cs" );
}