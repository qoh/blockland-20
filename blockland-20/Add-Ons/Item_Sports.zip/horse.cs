// horse.cs contains all datablocks for horse

// dodgeball 
datablock ShapeBaseImageData( horseDodgeballImage : dodgeballImage )
{
	mountPoint = 3;
	offset = "0 0.2 -0.3";
	rotation = "0 0 1 180";
	eyeOffset = "0 1 -0.5";
};

function horseDeDodge( %obj )
{
	if( !isObject( %obj ) )
		return;
		
	%obj.setImageTrigger( 0, 1 );
	%obj.setimageTrigger( 0, 0 );
}

function horseDodgeballImage::onMount(%this,%obj)
{	
	dodgeballImage::onMount(%this,%obj);
	
	// if we're a bot vehicle throw the dodgeball after a few seconds
	if( isObject( %obj.spawnBrick ) )
		schedule( 3000, %obj, horseDeDodge, %obj );
		
}

function horseDodgeballImage::onUnMount(%this,%obj)
{
	dodgeballImage::onUnMount(%this,%obj);
}
function horseDodgeballImage::onFire(%this,%obj,%slot)
{
	dodgeballImage::onFire(%this,%obj,%slot);
}

function horseDodgeballImage::onBallTrigger(%this, %obj, %trigger, %val)
{
	//maybe we should make it so you have to click to bounce other dodgeballs off you?
}

// basketball
datablock ShapeBaseImageData( horseBasketballImage : basketballShootImage )
{
	mountPoint = 3;
	offset = "0 0.2 -0.3";
	eyeOffset = "0 1 -0.5";
};

function horseBasketballImage::onMount(%this,%obj)
{	
	basketballShootImage::onMount(%this,%obj);
}

function horseBasketballImage::onUnMount(%this,%obj)
{
	basketballShootImage::onUnMount(%this,%obj);
}
function horseBasketballImage::onFire(%this,%obj,%slot)
{
	basketballShootImage::onFire(%this,%obj,%slot);
}

function horseBasketballImage::onBallTrigger(%this, %obj, %trigger, %val)
{
	basketballShootImage::onBallTrigger(%this, %obj, %trigger, %val);
}

// football
datablock ShapeBaseImageData( horseFootballImage : footballImage )
{
	//offset = "0.1 0.1 0";
	mountPoint = 3;
	offset = "0 0.1 -0";
	eyeOffset = "0 1 -0.5";
	eyeRotation = eulerToMatrix( "0 35 90" );
	rotation = eulerToMatrix( "0 35 90" );
};

function horseFootballImage::onMount(%this,%obj)
{	
	footballImage::onMount(%this,%obj);
}

function horseFootballImage::onUnMount(%this,%obj)
{
	footballImage::onUnMount(%this,%obj);
}
function horseFootballImage::onFire(%this,%obj,%slot)
{
	footballImage::onFire(%this,%obj,%slot);
}

function horseFootballImage::onCharge(%this, %obj, %slot)
{
	//footballImage::onCharge(%this, %obj, %slot);
}

function horseFootballImage::onBallTrigger(%this, %obj, %trigger, %val)
{
	footballImage::onBallTrigger(%this, %obj, %trigger, %val);
}

// soccerball

datablock ShapeBaseImageData( horseSoccerBallImage : soccerBallImage)
{
	offset = "0.35 1.8 0.35";
};

function horseSoccerBallImage::onBallTrigger(%this, %obj, %trigger, %val)
{
	soccerBallImage::onBallTrigger(%this, %obj, %trigger, %val);
}

function horseSoccerBallImage::onFire(%this,%obj,%slot)
{
	soccerBallImage::onFire(%this,%obj,%slot);
}

function horseSoccerBallImage::onMount(%this,%obj)
{	
	soccerBallImage::onMount(%this,%obj);
}

function horseSoccerBallImage::onUnMount(%this,%obj)
{
	soccerBallImage::onUnMount(%this,%obj);
}

// stand
datablock ShapeBaseImageData( horseSoccerBallStandImage : soccerBallImage)
{
	offset = "0.35 1.8 0.35";
	stateSequence[1]		= "root";
	stateSequence[4]		= "root";
};

function horseSoccerBallStandImage::onBallTrigger(%this, %obj, %trigger, %val)
{
	soccerBallImage::onBallTrigger(%this, %obj, %trigger, %val);
}

function horseSoccerBallStandImage::onFire(%this,%obj,%slot)
{
	soccerBallImage::onFire(%this,%obj,%slot);
}

function horseSoccerBallStandImage::onMount(%this,%obj)
{	
	soccerBallImage::onMount(%this,%obj);
}

function horseSoccerBallStandImage::onUnMount(%this,%obj)
{
	soccerBallImage::onUnMount(%this,%obj);
}


