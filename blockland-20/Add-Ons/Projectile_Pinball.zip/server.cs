
//trail
datablock ParticleData(pinballTrailParticle)
 {
   dragCoefficient      = 3;
   gravityCoefficient   = -0.0;
   inheritedVelFactor   = 0.15;
   constantAcceleration = 0.0;
   lifetimeMS           = 200;
   lifetimeVarianceMS   = 0;
   textureName          = "base/data/particles/dot";
   spinSpeed		   = 0.0;
   spinRandomMin		= 0.0;
   spinRandomMax		= 0.0;
   colors[0]     = "0.5 0.5 0.9 0.2";
   colors[1]     = "0.5 0.5 0.9 0.1";
   colors[2]     = "0.5 0.5 0.9 0.0";

   sizes[0]      = 0.18;
   sizes[1]      = 0.1;
   sizes[2]      = 0.0;

   times[0] = 0.0;
   times[1] = 0.5;
   times[2] = 1.0;

   useInvAlpha = false;
};
datablock ParticleEmitterData(pinballTrailEmitter)
{
   ejectionPeriodMS = 15;
   periodVarianceMS = 1;
   ejectionVelocity = 0.25;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "pinballTrailParticle";

   uiName = "Pinball Trail";
};

datablock ProjectileData(pinballProjectile)
{
   projectileShapeName = "./pinballProjectile.dts";
   explosion           = "";
   bounceExplosion     = "";
   particleEmitter     = pinballTrailEmitter;
   explodeOnDeath = true;

   brickExplosionRadius = 0;
   brickExplosionImpact = 0;             //destroy a brick if we hit it directly?
   brickExplosionForce  = 0;             
   brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   sound = "";

   muzzleVelocity      = 65;
   velInheritFactor    = 1.0;

   armingDelay         = 10000;
   lifetime            = 10000;
   fadeDelay           = 9500;
   bounceElasticity    = 0.90;
   bounceFriction      = 0.00;
   isBallistic         = true;
   gravityMod          = 1.0;

   hasLight    = false;

   uiName = "Pinball"; 
};