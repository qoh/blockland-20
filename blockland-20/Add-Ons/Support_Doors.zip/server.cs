//server.cs -- for Brick_Doors, execute all things in here

// dev function to help me keep my sanity
function execDoors()
{
	exec( "Add-Ons/Support_Doors/server.cs");
	exec( "Add-Ons/Brick_Doors/server.cs" );
}

// main scripts
exec( "./doors.cs" );