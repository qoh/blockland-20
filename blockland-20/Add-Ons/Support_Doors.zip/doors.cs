//Doors.cs, alls doors all the time

// datablock fxDTSBrickData ( brickDoorTestData )
// {
	// brickFile = "./testDoor.blb";
	// category = "special";
	// subCategory = "misc";
	// uiName = "Door Test";
	// iconName = "./placeholder";
	// orientationFix = 1;
// };

// called when door is opened
function fxDTSBrick::onDoorOpen( %obj, %client )
{
	%data = %obj.getDataBlock();
	
	// add a delay so people can't do loops
	if( %obj.onDoorOpenDelay > getSimTIme() )
		return;
		
	%obj.onDoorOpenDelay = getSimTime() + 33;

	$InputTarget_["Self"]   = %obj;
	$InputTarget_["Player"] = %client.player;
	$InputTarget_["Client"] = %client;
	$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);

	%obj.processInputEvent("onDoorOpen", %client);
}

registerInputEvent( "fxDTSBrick", "onDoorOpen", "Self fxDTSBrick" );// TAB "Player Player" TAB "Client GameConnection"

// called when door is closed
function fxDTSBrick::onDoorClose( %obj, %client )
{
	%data = %obj.getDataBlock();
	
	// add a delay so people can't do loops
	if( %obj.onDoorClosedDelay > getSimTIme() )
		return;
		
	%obj.onDoorClosedDelay = getSimTime() + 33;

	$InputTarget_["Self"]   = %obj;
	$InputTarget_["Player"] = %client.player;
	$InputTarget_["Client"] = %client;
	$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);

	%obj.processInputEvent("onDoorClose", %client);
}

registerInputEvent( "fxDTSBrick", "onDoorClose", "Self fxDTSBrick" );// TAB "Player Player" TAB "Client GameConnection"

function fxDTSBrick::setDoorDataBlock( %obj, %data )
{
	// if( %obj.lastDoorDataBlockSwitch + 100 > getSimTime() )
		// return;
	
	if( !isObject( %data ) )
	{
		error( "SetDoorDataBlock : " @ %data SPC "not found" );
		return;
	}
	
	%obj.setDataBlock( %data );
	%obj.lastDoorDataBlockSwitch = getSimTime();
	
	// play sound
	if( %data.noBrickSounds )
		return;
		
	%obj.playSound( "BrickChangeSound" );
}

function fxDTSBrick::doorOpen( %obj, %ccw, %client )
{
	%data = %obj.getDataBlock();
	
	if( !%data.isDoor )
		return;
	
	if( %obj.lastDoorDataBlockSwitch + 95 > getSimTime() )
		return;
		
	// do rotation check, clockwise or not
	if( !%ccw )
		%newDataBlock = %data.openCW;
	else
		%newDataBlock = %data.openCCW;

	%obj.isCCW = %ccw;
	
	// if we're trying to set as the same datablock don't do anything
	if( %data.getName() $= %newDataBlock )
		return;
	
	// onDoorOpen event
	%obj.onDoorOpen( %client );
	
	// if( !%ccw )
		// %obj.setDoorDataBlock( %data.openCW );
	// else
	
	// set the datablock
	%obj.setDoorDataBlock( %newDataBlock );
}

function fxDTSBrick::doorClose( %obj, %client )
{
	%data = %obj.getDataBlock();
	
	if( !%data.isDoor )
		return;
	
	if( %obj.lastDoorDataBlockSwitch + 95 > getSimTime() )
		return;
		
	// onDoorClose event
	%obj.onDoorClose( %client );
	
	if( %obj.isCCW )
		%obj.setDoorDataBlock( %data.closedCCW );
	else
		%obj.setDoorDataBlock( %data.closedCW );
}

//door event function, %obj is brick, %rot is the way we're trying to open the door
function fxDTSBrick::door( %obj, %rot, %client )
{
	// get the datablock and check if this is a door
	%data = %obj.getDataBlock();
	
	// if it's not a door return
	if( !%data.isDoor )
		return;
	
	// if we're a legacy door brick then let's go to our own function
	if( %data.isJVS )
	{
		%obj.doorJVS( %rot, %client );
		return;
	}
	
	// door states
	%toggleCW = 0;
	%toggleCCW = 1;
	%openCW = 2;
	%openCCW = 3;
	%close = 4;
	
	// %obj.doorOpen( 0, %client );
	// %obj.doorClose( %client );
	
	if( %rot == %toggleCW )
	{
		// toggle the state, default setting
		if( %data.isOpen )
			%obj.doorClose( %client );
		else
			%obj.doorOpen( 0, %client );
	}
	else if( %rot == %toggleCCW )
	{
		if( %data.isOpen )
			%obj.doorClose( %client );
		else
			%obj.doorOpen( 1, %client );
	}
	else if( %rot == %openCW )
	{
		// open it
		// if( !%data.isOpen )
		%obj.doorOpen( 0, %client );
	}
	else if( %rot == %openCCW )
	{
		// open it
		// if( !%data.isOpen )
		%obj.doorOpen( 1, %client );
	}
	else if( %rot == %close )
	{
		// close it
		if( %data.isOpen )
			%obj.doorClose( %client );
	}
}

registerOutputEvent( "fxDTSBrick", "door", "list Toggle 0 ToggleCCW 1 OpenCW 2 OpenCCW 3 Close 4", 1 );

// eventDelay0 = "0"
// eventEnabled0 = "1"
// eventInput0 = "onActivate"
// eventInputIdx0 = "0"
// eventOutput0 = "door"
// eventOutputAppendClient0 = "1"
// eventOutputIdx0 = "37"
// eventOutputParameter0_1 = "0"
// eventTarget0 = "Self"
// eventTargetIdx0 = "0"


// eventDelay1 = "0"
// eventEnabled1 = "1"
// eventInput1 = "onDoorOpen"
// eventInputIdx1 = "9"
// eventOutput1 = "playSound"
// eventOutputAppendClient1 = "1"
// eventOutputIdx1 = "16"
// eventOutputParameter1_1 = "823"
// eventTarget1 = "Self"
// eventTargetIdx1 = "0"

// eventDelay2 = "0"
// eventEnabled2 = "1"
// eventInput2 = "onDoorClose"
// eventInputIdx2 = "10"
// eventOutput2 = "playSound"
// eventOutputAppendClient2 = "1"
// eventOutputIdx2 = "16"
// eventOutputParameter2_1 = "824"
// eventTarget2 = "Self"
// eventTargetIdx2 = "0"

// numEvents = "3"

//packaged functions
package happyDoorFunTime
{
	//add events if we're a door brick, only in onPlant
	function fxDTSBrick::onPlant( %obj )
	{
		%data = %obj.getDataBlock();
		
		//apply events
		if( %data.isDoor && !%data.skipDoorEvents )
		{
			%obj.eventDelay0 = 0;
			%obj.eventEnabled0 = 1;
			%obj.eventInput0 = "onActivate";
			%obj.eventInputIdx0 = inputEvent_GetInputEventIdx( "onActivate" );
			%obj.eventOutput0 = "door";
			%obj.eventOutputAppendClient0 = 1;
			%obj.eventOutputIdx0 = outputEvent_GetOutputEventIdx( "fxDTSBrick","door" );//37;
			%obj.eventOutputParameter0_1 = 0;
			%obj.eventTarget0 = "Self";
			%obj.eventTargetIdx0 = 0;
			%obj.numEvents = 1;
		}
		
		if( !$disableJVSSounds && %data.isJVS &&  isObject( %data.datablockSoundStart ) && isObject( %data.datablockSoundStop )  )
		{
			%obj.eventDelay1 = %data.soundDelayStart;//"0";
			%obj.eventEnabled1 = "1";
			%obj.eventInput1 = "onDoorOpen";
			%obj.eventInputIdx1 = inputEvent_GetInputEventIdx( "onDoorOpen" );
			%obj.eventOutput1 = "playSound";
			%obj.eventOutputAppendClient1 = "1";
			%obj.eventOutputIdx1 = outputEvent_GetOutputEventIdx( "fxDTSBrick","playSound" );//"16";
			%obj.eventOutputParameter1_1 = %data.datablockSoundStart.getID();//"823";
			%obj.eventTarget1 = "Self";
			%obj.eventTargetIdx1 = "0";

			%obj.eventDelay2 = %data.soundDelayStop;//"0";
			%obj.eventEnabled2 = "1";
			%obj.eventInput2 = "onDoorClose";
			%obj.eventInputIdx2 = inputEvent_GetInputEventIdx( "onDoorClose" );
			%obj.eventOutput2 = "playSound";
			%obj.eventOutputAppendClient2 = "1";
			%obj.eventOutputIdx2 = outputEvent_GetOutputEventIdx( "fxDTSBrick","playSound" );//"16";
			%obj.eventOutputParameter2_1 = %data.datablockSoundStop.getID();//"824";
			%obj.eventTarget2 = "Self";
			%obj.eventTargetIdx2 = "0";
			
			%obj.numEvents = 3;
		}
		
		// if jvs doors add sound event
		
		parent::onPlant( %obj );
		
		// check if jvs port
		if( %data.isJVS )
			%obj.contentCreate();
	}
	
	function fxDTSBrick::onLoadPlant( %obj )
	{
		%data = %obj.getDataBlock();
		
		// check if jvs port
		if( %data.isJVS )
			%obj.contentCreate();
			
		parent::onLoadPlant( %obj );
	}
};
activatePackage( happyDoorFunTime );