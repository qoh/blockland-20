datablock AudioProfile(Beep_Checkout_Sound)
{
	filename = "./Beep_Checkout.wav";
	description = AudioClosest3d;
	preload = false;
};

datablock AudioProfile(Beep_Denied_Sound : Beep_Checkout_Sound)
{
	filename = "./Beep_Denied.wav";
};

datablock AudioProfile(Beep_EKG_Sound : Beep_Checkout_Sound)
{
	filename = "./Beep_EKG.wav";
};

datablock AudioProfile(Beep_Key_Sound : Beep_Checkout_Sound)
{
	filename = "./Beep_Key.wav";
};

datablock AudioProfile(Beep_No_Sound : Beep_Checkout_Sound)
{
	filename = "./Beep_No.wav";
};

datablock AudioProfile(Beep_NoWay_Sound : Beep_Checkout_Sound)
{
	filename = "./Beep_NoWay.wav";
};

datablock AudioProfile(Beep_Popup_Sound : Beep_Checkout_Sound)
{
	filename = "./Beep_Popup.wav";
};

datablock AudioProfile(Beep_Siren_Sound : Beep_Checkout_Sound)
{
	filename = "./Beep_Siren.wav";
};

datablock AudioProfile(Beep_TryAgain_Sound : Beep_Checkout_Sound)
{
	filename = "./Beep_TryAgain.wav";
};