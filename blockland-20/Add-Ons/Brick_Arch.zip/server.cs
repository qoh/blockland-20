datablock fxDTSBrickData(brick1x3ArchData)
{
	brickFile = "./1x3arch.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "1x3 Arch";
	iconName = "Add-Ons/Brick_Arch/1x3 Arch";
	collisionShapeName = "./1x3arch.dts";
};

datablock fxDTSBrickData(brick1x4ArchData)
{
	brickFile = "./1x4arch.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "1x4 Arch";
	iconName = "Add-Ons/Brick_Arch/1x4 Arch";
	collisionShapeName = "./1x4arch.dts";
};

datablock fxDTSBrickData(brick1x5ArchData)
{
	brickFile = "./1x5arch.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "1x5 Arch";
	iconName = "Add-Ons/Brick_Arch/1x5 Arch";
	collisionShapeName = "./1x5arch.dts";
};

datablock fxDTSBrickData(brick1x6x1ArchData)
{
	brickFile = "./1x6x1arch.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "1x6x1 Arch";
	iconName = "Add-Ons/Brick_Arch/1x6x1 Arch";
	collisionShapeName = "./1x6x1arch.dts";
};

datablock fxDTSBrickData(brick1x6x2ArchData)
{
	brickFile = "./1x6x2arch.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "1x6x2 Arch";
	iconName = "Add-Ons/Brick_Arch/1x6x2 Arch";
	collisionShapeName = "./1x6x2arch.dts";
};

datablock fxDTSBrickData(brick1x8ArchData)
{
	brickFile = "./1x8arch.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "1x8 Arch";
	iconName = "Add-Ons/Brick_Arch/1x8 Arch";
	collisionShapeName = "./1x8arch.dts";
};

//upward facing arches
datablock fxDTSBrickData(brick1x3ArchUpData)
{
	brickFile = "./1x3archUp.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "1x3 Arch Up";
	iconName = "Add-Ons/Brick_Arch/1x3 Arch Up";
	collisionShapeName = "./1x3archUp.dts";
};

datablock fxDTSBrickData(brick1x4ArchUpData)
{
	brickFile = "./1x4archUp.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "1x4 Arch Up";
	iconName = "Add-Ons/Brick_Arch/1x4 Arch Up";
	collisionShapeName = "./1x4archUp.dts";
};

datablock fxDTSBrickData(brick1x5ArchUpData)
{
	brickFile = "./1x5archUp.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "1x5 Arch Up";
	iconName = "Add-Ons/Brick_Arch/1x5 Arch Up";
	collisionShapeName = "./1x5archUp.dts";
};

datablock fxDTSBrickData(brick1x6x1ArchUpData)
{
	brickFile = "./1x6x1archUp.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "1x6x1 Arch Up";
	iconName = "Add-Ons/Brick_Arch/1x6x1 Arch Up";
	collisionShapeName = "./1x6x1archUp.dts";
};

datablock fxDTSBrickData(brick1x6x2ArchUpData)
{
	brickFile = "./1x6x2archUp.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "1x6x2 Arch Up";
	iconName = "Add-Ons/Brick_Arch/1x6x2 Arch Up";
	collisionShapeName = "./1x6x2archUp.dts";
};

datablock fxDTSBrickData(brick1x8ArchUpData)
{
	brickFile = "./1x8archUp.blb";
	category = "Rounds";
	subCategory = "Arches";
	uiName = "1x8 Arch Up";
	iconName = "Add-Ons/Brick_Arch/1x8 Arch Up";
	collisionShapeName = "./1x8archUp.dts";
};