datablock fxDTSBrickData (brickPosterData)
{
	brickFile = "Add-Ons/Brick_Poster_8x/Poster 8x.blb";
	category = "Special"; 
	subCategory = "Misc";
	uiName = "Poster 8x";                  
	iconName = "Add-Ons/Brick_Poster_8x/Poster 8x";
   orientationFix = 2;
   hasPrint = 1;
	printAspectRatio = "Poster";
};
