//tribes style, limited fuel jets
datablock PlayerData(PlayerFuelJet : PlayerStandardArmor)
{
	minJetEnergy = 2;
	jetEnergyDrain = 2;
	canJet = 1;

	uiName = "Fuel-Jet Player";
	showEnergyBar = true;
};