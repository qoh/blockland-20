datablock fxDTSBrickData(brick8x8GrillData)
{
	brickFile = "./8x8grill.blb";
	category = "Special";
	subCategory = "Misc";
	uiName = "8x8 Grill";
   iconName = "Add-Ons/Brick_V15/8x8 Grill";
};

datablock fxDTSBrickData(brick1x4x2BarsData)
{
	brickFile = "./1x4x2bars.blb";
	category = "Special";
	subCategory = "Walls";
	uiName = "1x4x2 Bars";
   orientationFix = 2;
   iconName = "Add-Ons/Brick_V15/1x4x2 Bars";
};

datablock fxDTSBrickData(brick4x1x2PicketData)
{
	brickFile = "./4x1x2picket.blb";
	category = "Special";
	subCategory = "Walls";
	uiName = "1x4x2 Picket";
	orientationFix = 1;
   iconName = "Add-Ons/Brick_V15/1x4x2 Picket";
};

datablock fxDTSBrickData(brick2x2cornerData)
{
	brickFile = "./2x2corner.blb";
	category = "Bricks";
	subCategory = "2x";
	uiName = "2x2 Corner";
   iconName = "Add-Ons/Brick_V15/2x2 Corner";
};