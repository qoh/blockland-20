datablock ItemData(blueKeyItem : redKeyItem)
{
   shapeFile = "Add-Ons/Item_Key/keyD.dts";
   uiName = "Key Blue";
   colorShiftColor = "0.0 0.0 1.0 1.0";
   iconName = "Add-Ons/Item_Key/Icon_KeyD";
   image = blueKeyImage;
};

datablock ShapeBaseImageData(blueKeyImage : redKeyImage)
{
   shapeFile = "Add-Ons/Item_Key/keyD.dts";
   colorShiftColor = blueKeyItem.colorShiftColor;
};

function blueKeyImage::onPreFire(%this, %obj, %slot)
{
	redKeyImage::onPreFire(%this, %obj, %slot);
}

function blueKeyImage::onStopFire(%this, %obj, %slot)
{	
	redKeyImage::onStopFire(%this, %obj, %slot);
}

function blueKeyImage::onFire(%this, %player, %slot)
{
   redKeyImage::onFire(%this, %player, %slot);
}

function blueKeyImage::onHitObject(%this, %player, %slot, %hitObj, %hitPos, %hitNormal)
{
   redKeyImage::onHitObject(%this, %player, %slot, %hitObj, %hitPos, %hitNormal);
}