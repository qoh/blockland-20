datablock ItemData(redKeyItem)
{
	 // Basic Item Properties
	shapeFile = "Add-Ons/Item_Key/keyA.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui properties
	uiName = "Key Red";
	iconName = "Add-Ons/Item_Key/Icon_KeyA";
	doColorShift = true;
	colorShiftColor = "1.0 0.0 0.0 1.0";

	 // Dynamic properties defined by the scripts
	image = redKeyImage;
	canDrop = true;
};

datablock ShapeBaseImageData(redKeyImage)
{
   // Basic Item properties
   shapeFile = "Add-Ons/Item_Key/keyA.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = redKeyItem;
   ammo = " ";
   projectile = "";
   projectileType = "";

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   showBricks = false;

   //casing = " ";

   doColorShift = true;
   colorShiftColor = redKeyItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.0;
	stateTransitionOnTimeout[0]      = "Ready";

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "PreFire";
	stateAllowImageChange[1]         = true;

	stateName[2]                    = "PreFire";
	stateScript[2]                  = "onPreFire";
	stateAllowImageChange[2]        = true;
	stateTimeoutValue[2]            = 0.01;
	stateTransitionOnTimeout[2]     = "Fire";

	stateName[3]                    = "Fire";
	stateTransitionOnTimeout[3]     = "CheckFire";
	stateTimeoutValue[3]            = 0.15;
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = true;
	stateSequence[3]                = "Fire";
	stateScript[3]                  = "onFire";
	stateWaitForTimeout[3]		     = true;
	stateSequence[3]                = "Fire";

	stateName[4]                    = "CheckFire";
	stateTransitionOnTriggerUp[4]   = "StopFire";

	stateName[5]                    = "StopFire";
	stateTransitionOnTimeout[5]     = "Ready";
	stateTimeoutValue[5]            = 0.01;
	stateAllowImageChange[5]        = true;
	stateWaitForTimeout[5]          = true;
	stateSequence[5]                = "StopFire";
	stateScript[5]                  = "onStopFire";
};

function redKeyImage::onPreFire(%this, %obj, %slot)
{
	%obj.playthread(2, shiftLeft);
}

function redKeyImage::onStopFire(%this, %obj, %slot)
{	
	%obj.playthread(2, root);
}

function redKeyImage::onFire(%this, %player, %slot)
{
   %start = %player.getEyePoint();
   %vec = vectorScale(%player.getMuzzleVector(%slot), 10  * getWord(%player.getScale(), 2) );
   %end = vectorAdd(%start, %vec);
   %mask = $TypeMasks::InteriorObjectType | $TypeMasks::TerrainObjectType | $TypeMasks::FxBrickObjectType;

   %rayCast = containerRayCast(%start,%end,%mask);

   if(!%rayCast)
      return;

   %hitObj = getWord(%rayCast, 0);
   %hitPos = getWords(%rayCast, 1, 3);
   %hitNormal = getWords(%rayCast, 4, 6);

   %this.onHitObject(%player, %slot, %hitObj, %hitPos, %hitNormal);   
}


// r,g,b values are from 0 to 1
// h = [0,360], s = [0,1], v = [0,1]
//		if s == 0, then h = -1 (undefined)
function RGBtoHSV(%r, %g, %b)
{
	%min = getMin(%r, getMin(%g, %b));
	%max = getMax(%r, getMax(%g, %b));

	%delta = %max - %min;
	%v = %max;

	if(%max != 0)
	{
		%s = %delta / %max;
      
      if(%delta == 0)
      {
         %h = -12;
      }
      else
      {
         if(%r == %max)
            %h = (%g - %b) / %delta;
         else if(%g == %max)
            %h = 2 + ( %b - %r ) / %delta;
         else	
            %h = 4 + ( %r - %g ) / %delta;
      }

		%h *= 60;
		if(%h < 0)
			%h += 360;
	}
	else
	{
		%s = 0;
		%h = 0;
		%v = 0;
	}

	%h = %h / 360;
	
	return (%h SPC %s SPC %v);		
}


function redKeyImage::onHitObject(%this, %player, %slot, %hitObj, %hitPos, %hitNormal)
{
   %client = %player.client;

   if(%hitObj.getType() & $TypeMasks::FxBrickAlwaysObjectType)
   {
      //determine if color matches or not via hue comparison

      //get brick color
      %brickRGBA = getColorIDTable(%hitObj.getColorId());
      %r = getWord(%brickRGBA, 0);
      %g = getWord(%brickRGBA, 1);
      %b = getWord(%brickRGBA, 2);
      //echo("brick rgb = " @ %r SPC %g SPC %b);
      //echo("brick hsv " @ RGBtoHSV(%r,%g,%b));
      %brickH = getWord(RGBtoHSV(%r,%g,%b), 0);

      %brickRGB = %r SPC %g SPC %b;
      %brickRGB = vectorNormalize(%brickRGB);
      
      //get key color
      %keyRGBA = %this.colorShiftColor;
      %r = getWord(%keyRGBA, 0);
      %g = getWord(%keyRGBA, 1);
      %b = getWord(%keyRGBA, 2);
      //echo("key rgb = " @ %r SPC %g SPC %b);
      //echo("key hsv " @ RGBtoHSV(%r,%g,%b));
      %keyH = getWord(RGBtoHSV(%r,%g,%b), 0);

      %keyRGB = %r SPC %g SPC %b;
      %keyRGB = vectorNormalize(%keyRGB);

      //compare
      %hDiff = mAbs(%keyH - %brickH);
      if(%hDiff > 0.5)
         %hDiff = 1 - %hDiff;

      //echo("hDiff = " @ %hDiff);
      
      %rgbDiff = vectorSub(%brickRGB, %keyRGB);
      %rgbDiffLen = vectorLen(%rgbDiff);
      //echo("rgbDiffLen = " @ %rgbDiffLen);
      
      if(%hDiff > 0.1 || (%keyH >= 0 && %brickH < 0) || (%keyH < 0 && %brickH >= 0))
      {
         //echo("NO MATCH");
         %hitObj.onKeyMismatch(%player);
      }
      else
      {
         //echo("MATCH");
         %hitObj.onKeyMatch(%player);
      }
      
   }
}

function fxDTSBrick::OnKeyMatch(%obj, %player)
{
   %client = %player.client;

   $InputTarget_["Self"]   = %obj;
   $InputTarget_["Player"] = %player;
   $InputTarget_["Client"] = %client;

   if($Server::LAN)
   {
      $InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
   }
   else
   {
      if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
         $InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
      else
         $InputTarget_["MiniGame"] = 0;
   }

   %obj.processInputEvent("OnKeyMatch", %client);
}


function fxDTSBrick::OnKeyMismatch(%obj, %player)
{
   %client = %player.client;

   $InputTarget_["Self"]   = %obj;
   $InputTarget_["Player"] = %player;
   $InputTarget_["Client"] = %client;

   if($Server::LAN)
   {
      $InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
   }
   else
   {
      if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
         $InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
      else
         $InputTarget_["MiniGame"] = 0;
   }

   %obj.processInputEvent("OnKeyMismatch", %client);
}

registerInputEvent("fxDTSBrick", "OnKeyMatch", "Self fxDTSBrick" TAB 
                                               "Player Player" TAB 
                                               "Client GameConnection" TAB
                                               "MiniGame MiniGame");

registerInputEvent("fxDTSBrick", "OnKeyMismatch", "Self fxDTSBrick" TAB 
                                                  "Player Player" TAB 
                                                  "Client GameConnection" TAB
                                                  "MiniGame MiniGame");



exec("./yellowKey.cs");
exec("./greenKey.cs");
exec("./blueKey.cs");