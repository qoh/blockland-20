datablock ItemData(greenKeyItem : redKeyItem)
{
   shapeFile = "Add-Ons/Item_Key/keyC.dts";
   uiName = "Key Green";
   colorShiftColor = "0.0 1.0 0.0 1.0";
   iconName = "Add-Ons/Item_Key/Icon_KeyC";
   image = greenKeyImage;
};

datablock ShapeBaseImageData(greenKeyImage : redKeyImage)
{
   shapeFile = "Add-Ons/Item_Key/keyC.dts";
   colorShiftColor = greenKeyItem.colorShiftColor;
};

function greenKeyImage::onPreFire(%this, %obj, %slot)
{
	redKeyImage::onPreFire(%this, %obj, %slot);
}

function greenKeyImage::onStopFire(%this, %obj, %slot)
{	
	redKeyImage::onStopFire(%this, %obj, %slot);
}

function greenKeyImage::onFire(%this, %player, %slot)
{
   redKeyImage::onFire(%this, %player, %slot);
}

function greenKeyImage::onHitObject(%this, %player, %slot, %hitObj, %hitPos, %hitNormal)
{
   redKeyImage::onHitObject(%this, %player, %slot, %hitObj, %hitPos, %hitNormal);
}