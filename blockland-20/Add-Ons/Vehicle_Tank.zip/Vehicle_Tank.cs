datablock TSShapeConstructor(TankTurretDts)
{
	baseShape  = "./tank_turret.dts";
	sequence0  = "./t_root.dsq root";

	sequence1  = "./t_root.dsq run";
	sequence2  = "./t_root.dsq walk";
	sequence3  = "./t_root.dsq back";
	sequence4  = "./t_root.dsq side";

	sequence5  = "./t_root.dsq crouch";
	sequence6  = "./t_root.dsq crouchRun";
	sequence7  = "./t_root.dsq crouchBack";
	sequence8  = "./t_root.dsq crouchSide";

	sequence9  = "./t_look.dsq look";
	sequence10 = "./t_root.dsq headside";
	sequence11 = "./t_root.dsq headUp";

	sequence12 = "./t_root.dsq jump";
	sequence13 = "./t_root.dsq standjump";
	sequence14 = "./t_root.dsq fall";
	sequence15 = "./t_root.dsq land";

	sequence16 = "./t_root.dsq armAttack";
	sequence17 = "./t_root.dsq armReadyLeft";
	sequence18 = "./t_root.dsq armReadyRight";
	sequence19 = "./t_root.dsq armReadyBoth";
	sequence20 = "./t_root.dsq spearready";  
	sequence21 = "./t_root.dsq spearThrow";

	sequence22 = "./t_root.dsq talk";  

	sequence23 = "./t_root.dsq death1"; 
	
	sequence24 = "./t_root.dsq shiftUp";
	sequence25 = "./t_root.dsq shiftDown";
	sequence26 = "./t_root.dsq shiftAway";
	sequence27 = "./t_root.dsq shiftTo";
	sequence28 = "./t_root.dsq shiftLeft";
	sequence29 = "./t_root.dsq shiftRight";
	sequence30 = "./t_root.dsq rotCW";
	sequence31 = "./t_root.dsq rotCCW";

	sequence32 = "./t_root.dsq undo";
	sequence33 = "./t_root.dsq plant";

	sequence34 = "./t_root.dsq sit";

	sequence35 = "./t_root.dsq wrench";
};    

datablock AudioProfile(TankShotSound)
{
   filename    = "./shot.wav";
   description = AudioDefault3d;
   preload = true;
};

datablock PlayerData(TankTurretPlayer)
{
   renderFirstPerson = true;
   emap = false;
   
   className = Armor;
   shapeFile = "./tank_turret.dts";
   cameraMaxDist = 8;
   cameraTilt = 0.261;
   cameraVerticalOffset = 2.3;
     
   cameraDefaultFov = 90.0;
   cameraMinFov = 5.0;
   cameraMaxFov = 120.0;
   
   //debrisShapeName = "~/data/player/debris_player.dts";
   //debris = horseDebris;

   aiAvoidThis = true;

   minLookAngle = -1.5708;
   maxLookAngle = 0.5;
   maxFreelookAngle = 3.0;

   mass = 200000;
   drag = 1;
   density = 5;
   maxDamage = 250;
   maxEnergy =  10;
   repairRate = 0.33;

   rechargeRate = 0.4;

   runForce = 1000;
   runEnergyDrain   = 0;
   minRunEnergy     = 0;
   maxForwardSpeed  = 0;
   maxBackwardSpeed = 0;
   maxSideSpeed     = 0;

   maxForwardCrouchSpeed  = 0;
   maxBackwardCrouchSpeed = 0;
   maxSideCrouchSpeed     = 0;

   maxUnderwaterForwardSpeed  = 0;
   maxUnderwaterBackwardSpeed = 0;
   maxUnderwaterSideSpeed     = 0;

   jumpForce       = 0; 
   jumpEnergyDrain = 0;
   minJumpEnergy   = 0;
   jumpDelay       = 0;

   minJetEnergy   = 0;
	jetEnergyDrain = 0;
	canJet         = 0;

   minImpactSpeed   = 250;
   speedDamageScale = 3.8;

   boundingBox			= vectorScale("2.5 2.5 1.7", 4); 
   crouchBoundingBox	= vectorScale("2.5 2.5 1.7", 4); 
   
   pickupRadius = 0.75;
   
   // Foot Prints
   //decalData   = HorseFootprint;
   //decalOffset = 0.25;
	
   jetEmitter        = "";
   jetGroundEmitter  = "";
   jetGroundDistance = 4;
  
   //footPuffEmitter = LightPuffEmitter;
   footPuffNumParts = 10;
   footPuffRadius = 0.25;

   //dustEmitter = LiftoffDustEmitter;

   splash = PlayerSplash;
   splashVelocity = 4.0;
   splashAngle = 67.0;
   splashFreqMod = 300.0;
   splashVelEpsilon = 0.60;
   bubbleEmitTime = 0.1;
   splashEmitter[0] = PlayerFoamDropletsEmitter;
   splashEmitter[1] = PlayerFoamEmitter;
   splashEmitter[2] = PlayerBubbleEmitter;
   mediumSplashSoundVelocity = 10.0;   
   hardSplashSoundVelocity = 20.0;   
   exitSplashSoundVelocity = 5.0;

   // Controls over slope of runnable/jumpable surfaces
   runSurfaceAngle  = 85;
   jumpSurfaceAngle = 86;

   minJumpSpeed = 20;
   maxJumpSpeed = 30;

   horizMaxSpeed = 68;
   horizResistSpeed = 33;
   horizResistFactor = 0.35;

   upMaxSpeed = 80;
   upResistSpeed = 25;
   upResistFactor = 0.3;
   
   footstepSplashHeight = 0.35;

   //NOTE:  some sounds commented out until wav's are available

   JumpSound = "";

   // Footstep Sounds
   //FootSoftSound        = HorseFootFallSound;
   //FootHardSound        = HorseFootFallSound;
   //FootMetalSound       = HorseFootFallSound;
   //FootSnowSound        = HorseFootFallSound;
   //FootShallowSound     = HorseFootFallSound;
   //FootWadingSound      = HorseFootFallSound;
   //FootUnderwaterSound  = HorseFootFallSound;
   //FootBubblesSound     = FootLightBubblesSound;
   //movingBubblesSound   = ArmorMoveBubblesSound;
   //waterBreathSound     = WaterBreathMaleSound;

   //impactSoftSound      = ImpactLightSoftSound;
   //impactHardSound      = ImpactLightHardSound;
   //impactMetalSound     = ImpactLightMetalSound;
   //impactSnowSound      = ImpactLightSnowSound;
   
   //impactWaterEasy      = ImpactLightWaterEasySound;
   //impactWaterMedium    = ImpactLightWaterMediumSound;
   //impactWaterHard      = ImpactLightWaterHardSound;
   
   groundImpactMinSpeed    = 10.0;
   groundImpactShakeFreq   = "4.0 4.0 4.0";
   groundImpactShakeAmp    = "1.0 1.0 1.0";
   groundImpactShakeDuration = 0.8;
   groundImpactShakeFalloff = 10.0;
   
   //exitingWater         = ExitingWaterLightSound;

   // Inventory Items
	maxItems   = 10;	//total number of bricks you can carry
	maxWeapons = 5;		//this will be controlled by mini-game code
	maxTools = 5;
	
	uiName = "Tank Turret";
	rideable = true;
   lookUpLimit = 0.6;
   lookDownLimit = 0.4;

	canRide = false;
	showEnergyBar = false;
	paintable = true;

	brickImage = horseBrickImage;	//the imageData to use for brick deployment

   numMountPoints = 1;
   mountThread[0] = "root";

   //protection for passengers
   protectPassengersBurn   = true;  //protect passengers from the burning effect of explosions?
   protectPassengersRadius = true;  //protect passengers from radius damage (explosions) ?
   protectPassengersDirect = false; //protect passengers from direct damage (bullets) ?

   useCustomPainEffects = true;
   PainHighImage = "";
   PainMidImage  = "";
   PainLowImage  = "";
   painSound     = "";
   deathSound    = "";
};

datablock ParticleData(TankSmokeParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -1;
	inheritedVelFactor   = 0.6;
	constantAcceleration = 0.0;
	lifetimeMS           = 850;
	lifetimeVarianceMS   = 55;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.5 0.5 0.5 0.2";
	colors[1]     = "0.5 0.5 0.5 0.0";
	sizes[0]      = 0.6;
	sizes[1]      = 0.8;

	useInvAlpha = true;
};

datablock ParticleEmitterData(TankSmokeEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 4;
   ejectionVelocity = 3;
   velocityVariance = 2;
   ejectionOffset   = 0;
   thetaMin         = 0;
   thetaMax         = 50;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "TankSmokeParticle";

   uiName = "Tank Smoke";
};

datablock ShapeBaseImageData(TankSmokeImage)
{
	shapeFile = "base/data/shapes/empty.dts";
	emap = false;

	mountPoint = 1;

	stateName[0]                  = "Ready";
	stateTransitionOnTimeout[0]   = "FireA";
	stateTimeoutValue[0]          = 0.01;

	stateName[1]                  = "FireA";
	stateTransitionOnTimeout[1]   = "FireB";
	stateWaitForTimeout[1]        = True;
	stateTimeoutValue[1]          = 0.05;
	stateEmitter[1]               = vehicleFinalExplosionEmitter3;
	stateEmitterTime[1]           = 0.05;

	stateName[2]                  = "FireB";
	stateTransitionOnTimeout[2]   = "FireC";
	stateWaitForTimeout[2]        = True;
	stateTimeoutValue[2]          = 0.05;
	stateEmitter[2]               = vehicleExplosionEmitter; 
	stateEmitterTime[2]           = 0.05;

	stateName[3]                  = "FireC";
	stateTransitionOnTimeout[3]   = "Done";
	stateWaitForTimeout[3]        = True;
	stateTimeoutValue[3]          = 0.850;
	stateEmitter[3]               = TankSmokeEmitter;
	stateEmitterTime[3]           = 0.850;

	stateName[4]                  = "Done";
	stateScript[4]                = "onDone";
};
function TankSmokeImage::onDone(%this,%obj,%slot)
{
	%obj.unMountImage(%slot);
}

datablock WheeledVehicleTire(tankTire)
{
   // Tires act as springs and generate lateral and longitudinal
   // forces to move the vehicle. These distortion/spring forces
   // are what convert wheel angular velocity into forces that
   // act on the rigid body.
   shapeFile = "./emptyWheel.dts";
	
	mass = 10;
   radius = 1;
   staticFriction = 5;
   kineticFriction = 5;
   restitution = 0.5;	

   // Spring that generates lateral tire forces
   lateralForce = 18000;
   lateralDamping = 4000;
   lateralRelaxation = 0.01;

   // Spring that generates longitudinal tire forces
   longitudinalForce = 14000;
   longitudinalDamping = 2000;
   longitudinalRelaxation = 0.01;
};

datablock WheeledVehicleSpring(tankSpring)
{
   // Wheel suspension properties
   length = 0.4;        // Suspension travel
   force = 6000;        // Spring force
   damping = 2000;      // Spring damping
   antiSwayForce = 6;   // Lateral anti-sway force
};

datablock WheeledVehicleData(TankVehicle)
{
	category = "Vehicles";
	displayName = " ";
	shapeFile = "./tank.dts";
	emap = true;
	minMountDist = 3;
   
   numMountPoints = 3;
   mountThread[0] = "root";
   mountThread[1] = "root";
   mountThread[2] = "root";

	maxDamage = 300.00;
	destroyedLevel = 300.00;
	speedDamageScale = 1.04;
	collDamageThresholdVel = 20.0;
	collDamageMultiplier   = 0.02;

	massCenter = "0 0 0";
   //massBox = "2 5 1";

	maxSteeringAngle = 0.9785;  // Maximum steering angle, should match animation
	integration = 4;           // Force integration time: TickSec/Rate
	tireEmitter = VehicleTireEmitter; // All the tires use the same dust emitter

	// 3rd person camera settings
	cameraRoll = false;         // Roll the camera with the vehicle
	cameraMaxDist = 13;         // Far distance from vehicle
	cameraOffset = 7.5;        // Vertical offset from camera mount point
	cameraLag = 0.0;           // Velocity lag of camera
	cameraDecay = 0.75;        // Decay per sec. rate of velocity lag
	cameraTilt = 0.4;
   collisionTol = 0.1;        // Collision distance tolerance
   contactTol = 0.1;

	useEyePoint = false;	

	defaultTire	= tankTire;
	defaultSpring	= tankSpring;

   numWheels = 4;

	// Rigid Body
	mass = 300;
	density = 5.0;
	drag = 1.6;
	bodyFriction = 0.6;
	bodyRestitution = 0.6;
	minImpactSpeed = 10;        // Impacts over this invoke the script callback
	softImpactSpeed = 10;       // Play SoftImpact Sound
	hardImpactSpeed = 15;      // Play HardImpact Sound
	groundImpactMinSpeed    = 10.0;

	// Engine
	engineTorque = 25000; //4000;       // Engine power
	engineBrake = 5000;         // Braking when throttle is 0
	brakeTorque = 50000;        // When brakes are applied
	maxWheelSpeed = 20;        // Engine scale by current speed / max speed

	rollForce		= 900;
	yawForce		= 600;
	pitchForce		= 1000;
	rotationalDrag		= 0.2;

	// Energy
	maxEnergy = 100;
	jetForce = 3000;
	minJetEnergy = 30;
	jetEnergyDrain = 2;

	splash = vehicleSplash;
	splashVelocity = 4.0;
	splashAngle = 67.0;
	splashFreqMod = 300.0;
	splashVelEpsilon = 0.60;
	bubbleEmitTime = 1.4;
	splashEmitter[0] = vehicleFoamDropletsEmitter;
	splashEmitter[1] = vehicleFoamEmitter;
	splashEmitter[2] = vehicleBubbleEmitter;
	mediumSplashSoundVelocity = 10.0;   
	hardSplashSoundVelocity = 20.0;   
	exitSplashSoundVelocity = 5.0;
		
	//mediumSplashSound = "";
	//hardSplashSound = "";
	//exitSplashSound = "";
	
	// Sounds
	//   jetSound = ScoutThrustSound;
	//engineSound = rocketLoopSound;
	//squealSound = skidSound;
	softImpactSound = slowImpactSound;
	hardImpactSound = fastImpactSound;
	//wheelImpactSound = slowImpactSound;

	//   explosion = VehicleExplosion;
	justcollided = 0;

   uiName = "Tank ";
	rideable = true;
   //lookUpLimit = 0.9;
   //lookDownLimit = 0.1;
   lookUpLimit  = 0.5;
   lookDownLimit = 0.5;

	paintable = true;
   
   damageEmitter[0] = VehicleBurnEmitter;
	damageEmitterOffset[0] = "0.0 0.0 0.0 ";
	damageLevelTolerance[0] = 0.99;

   damageEmitter[1] = VehicleBurnEmitter;
	damageEmitterOffset[1] = "0.0 0.0 0.0 ";
	damageLevelTolerance[1] = 1.0;

   numDmgEmitterAreas = 1;

   initialExplosionProjectile = tankExplosionProjectile;
   initialExplosionOffset = 1;         //offset only uses a z value for now

   burnTime = 4000;

   finalExplosionProjectile = tankFinalExplosionProjectile;
   finalExplosionOffset = 0.5;          //offset only uses a z value for now


   minRunOverSpeed    = 4;   //how fast you need to be going to run someone over (do damage)
   runOverDamageScale = 25;   //when you run over someone, speed * runoverdamagescale = damage amt
   runOverPushScale   = 1.2; //how hard a person you're running over gets pushed

   //protection for passengers
   protectPassengersBurn   = true;  //protect passengers from the burning effect of explosions?
   protectPassengersRadius = true;  //protect passengers from radius damage (explosions) ?
   protectPassengersDirect = true; //protect passengers from direct damage (bullets) ?
};

function TankVehicle::onAdd(%this,%obj)
{
   // Setup the car with some defaults tires & springs
   for(%i = 0; %i < %this.numWheels; %i++)
   {
      %obj.setWheelTire(%i, %this.defaultTire);
      %obj.setWheelSpring(%i, %this.defaultSpring);
   }

   // 4 wheel steering
   %obj.setWheelSteering(0,1);
   %obj.setWheelSteering(1,1);
   %obj.setWheelSteering(2,-0.8);
   %obj.setWheelSteering(3,-0.8);

   // 4 wheel drive
   %obj.setWheelPowered(0,true);
   %obj.setWheelPowered(1,true);
   %obj.setWheelPowered(2,true);
   %obj.setWheelPowered(3,true);

   // turret
   %t = new AIPlayer()
   {
      dataBlock = TankTurretPlayer;
   };
   MissionCleanup.add(%t);
   %obj.mountObject(%t, 2);
   %obj.turret = %t;

   %obj.creationTime = getSimTime();
   %t.schedule(10,"rigTurret");
}

function Player::rigTurret(%obj)
{
   if(%obj.dataBlock !$= TankTurretPlayer)
	   return;

   if(!isObject(%obj))
	   return;

   %parent = %obj.getObjectMount();
   if(!isObject(%parent))
	   return;

   %obj.spawnBrick = %parent.spawnBrick;
   %obj.brickGroup = %parent.brickGroup;
}

function TankVehicle::onRemove(%this,%obj)
{
   if(isObject(%obj.turret))
	   %obj.turret.delete();
}

function TankTurretPlayer::onDriverLeave(%this,%obj)
{
   if(%obj.isMounted())
      %obj.setTransform("0 0 0 0 0 0 0");
}

function TankTurretPlayer::onAdd(%this, %obj)
{
   %obj.lastShotTime = getSimTime() - 2000;
   Parent::onAdd(%this, %obj);
}

package TankPackage
{
   function Player::burn(%obj,%time)
   {
      if(%obj.dataBlock $= TankTurretPlayer)
         return;
      else
         Parent::burn(%obj,%time);
   }

   function ShapeBase::setNodeColor(%obj,%node,%color)
   {
      Parent::setnodecolor(%obj,%node,%color);
      if(isObject(%obj.turret))
      {
         %obj.turret.setNodeColor("ALL",%color);
      }
   }

   function TankVehicle::Damage(%this,%obj,%source,%pos,%amm,%type)
   {
      if((%obj.getDamageLevel()+%amm) >= %this.maxDamage)
      {
         if(%obj.destroyed)
            return;

         %obj.setNodeColor("ALL","0 0 0 1");
         if(isObject(%obj.turret))
         {
            %obj.turret.delete();
            %p = new Projectile()
            {
               dataBlock = TankTurretExplosionProjectile;
               initialPosition = vectorAdd(%obj.getPosition(),"0 0" SPC %this.initialExplosionOffset);
               initialVelocity = "0 0 1";
               client = %obj.lastDamageClient;
               sourceClient = %obj.lastDamageClient;
            };
            MissionCleanup.add(%p);
         }
         else
         {
            %p = new Projectile()
            {
               dataBlock = TankExplosionProjectile;
               initialPosition = vectorAdd(%obj.getPosition(),"0 0" SPC %this.initialExplosionOffset);
               initialVelocity = "0 0 1";
               client = %obj.lastDamageClient;
               sourceClient = %obj.lastDamageClient;
            };
            MissionCleanup.add(%p);
         }
         if(%obj.destroyed)
            return;

         %obj.setDamageLevel(%this.maxDamage);
         %obj.destroyed = 1;
         %obj.schedule(%this.burnTime,"finalExplosion");
         if(isObject(%obj.spawnBrick.client.minigame))
            %respawn = %obj.spawnBrick.client.minigame.vehicleReSpawnTime;
         %obj.spawnBrick.schedule(%respawn,"spawnVehicle");
      }
      else
         Parent::Damage(%this,%obj,%source,%pos,%amm,%type);
   }

   function Player::emote(%obj,%emote)
   {
      if(%obj.dataBlock $= TankTurretPlayer)
	      return;
      Parent::emote(%obj,%emote);
   }

   function TankShellProjectile::onCollision(%this,%obj,%col,%a,%b,%c,%d,%e)
   {
      if(%col.dataBlock.className $= "Glass" && !%col.indestructable)
      {
         %col.explode();
      }
      Parent::onCollision(%this,%obj,%col,%a,%b,%c,%d,%e);
   }

   function TankTurretPlayer::onDisabled(%this,%obj,%state)
   {
      %tank = %obj.getObjectMount();
      if(isObject(%tank))
         %pos = vectorAdd(%obj.getObjectMount().getPosition(),"0 0" SPC %obj.getObjectMount().dataBlock.initialExplosionOffset);
      else
         %pos = %obj.getHackPosition();

      %p = new Projectile()
      {
         dataBlock = TankTurretExplosionProjectile;
         initialPosition = %pos;
         initialVelocity = "0 0 1";
         client = %obj.lastDamageClient;
         sourceClient = %obj.lastDamageClient;
      };
      MissionCleanup.add(%p);
      %obj.schedule(10,"delete");

      //mount the guy who was in the turret to the tank
      if(isObject(%tank))
      {
         %player = %obj.getMountedObject(0);
         if(isObject(%player))
         {
            %obj.getObjectMount().schedule(10,"mountObject",%player,2);
         }
      }
      
      if(!isObject(%tank))
      {
         if(isObject(%obj.spawnBrick))
         {
            %mg = getMiniGameFromObject(%obj);
            if(isObject(%mg))
            {
               %obj.spawnBrick.spawnVehicle(%mg.vehicleReSpawnTime);
            }
            else
            {
               %obj.spawnBrick.spawnVehicle(0);
            }         
         }
     
         Parent::onDisabled(%this,%obj,%state);              
      }
   }  

   function TankTurretPlayer::Damage(%data,%obj,%source,%pos,%amm,%type)
   {
      //scale the damage ammount as if this was a vehicle     
      %amm *= $Damage::VehicleDamageScale[%type];

      if(%obj.getDamageLevel()+%amm > %data.maxDamage && !isObject(%obj.client))
         %obj.setDamageLevel(%data.maxDamage);
      else
         Parent::Damage(%data,%obj,%source,%pos,%amm,%type);
   }

   function armor::onMount(%this,%obj,%col,%slot)
   {
      Parent::onMount(%this,%obj,%col,%slot);
      if(%col.getDataBlock() == TankVehicle.getId())
      {
         if(%slot $= 2)
         {
            %obj.setLookLimits(1,0);
         }
      }
      else if(%col.getDataBlock() == TankTurretPlayer.getId())
      {
         %client = %obj.client;
         if(isObject(%client))
            ServerCmdUnUseTool(%client);
      }
   }

   function armor::onTrigger(%this, %obj, %triggerNum, %val)
   {
      %mount = %obj.getObjectMount();

      //hack so we can shoot if we are a tank turret
      if(%obj.getDataBlock().getID() == TankTurretPlayer.getID())
         %mount = %obj;

      if(isObject(%mount))
      {
         if(%mount.getDataBlock() == TankTurretPlayer.getId() && %triggerNum == 0 && %val)
         {
            %client = %obj.client;
            if(isObject(%client))
               ServerCmdUnUseTool(%client);

            if(getSimTime() - %obj.lastShotTime < 2500)
               return;
            
            %scaleFactor = getWord(%mount.getScale(), 2);
            %p = new Projectile()
            {
               dataBlock = tankShellProjectile;
               initialPosition = %mount.getSlotTransform(1);
               initialVelocity = vectorScale(%mount.getMuzzleVector(1),140 * %scaleFactor);
               sourceObject = %obj;
               client = %obj.client;
               sourceSlot = 0;
               originPoint = %mount.getSlotTransform(1);
            };
            MissionCleanup.add(%p);
            %p.setScale(%scaleFactor SPC %scaleFactor SPC %scaleFactor);

            %mount.mountImage(TankSmokeImage,1);

            serverPlay3D(TankshotSound,%obj.getPosition());
         
            %tank = %mount.getObjectMount();
            if(isObject(%tank))
            {
               %theVector = %mount.getEyeVector();
               %theVector = vectorAdd(%theVector,"0 0 1");
               %theVector = vectorScale(%theVector,%tank.getDataBlock().mass*5);
               %theVector = vectorSub(%theVector,vectorScale(%thevector,2));
               
               %tank.applyImpulse(getWords(%mount.getEyeTransform(),0,2),%theVector);	
            }
            
            %obj.playThread(0,activate);
            %obj.lastShotTime = getSimTime();

            return;
         }
      }
      
      Parent::onTrigger(%this,%obj,%triggerNum,%val);
   }
};
activatepackage(TankPackage);

datablock DebrisData(turretDebris)
{
   emitters = "jeepDebrisTrailEmitter";

	shapeFile = "./tank_turretDebris.dts";
	lifetime = 3.0;
	minSpinSpeed = -300.0;
	maxSpinSpeed = 300.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 1;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 2;
};

datablock ExplosionData(tankExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 150;

   soundProfile = vehicleExplosionSound;
   
   emitter[0] = vehicleExplosionEmitter;
   emitter[1] = vehicleExplosionEmitter2;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "7.0 8.0 7.0";
   camShakeAmp = "10.0 10.0 10.0";
   camShakeDuration = 0.75;
   camShakeRadius = 15.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 20;
   lightStartColor = "0.45 0.3 0.1";
   lightEndColor = "0 0 0";

   //impulse
   impulseRadius = 15;
   impulseForce = 1000;
   impulseVertical = 2000;

   //radius damage
   radiusDamage        = 30;
   damageRadius        = 8.0;

   //burn the players?
   playerBurnTime = 5000;

};

datablock ProjectileData(tankExplosionProjectile)
{
   directDamage        = 0;
   radiusDamage        = 0;
   damageRadius        = 0;
   explosion           = tankExplosion;

   directDamageType  = $DamageType::jeepExplosion;
   radiusDamageType  = $DamageType::jeepExplosion;

   explodeOnDeath		= 1;

   armingDelay         = 0;
   lifetime            = 10;
};

datablock ExplosionData(tankTurretExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 150;

   soundProfile = vehicleExplosionSound;
   
   emitter[0] = vehicleExplosionEmitter;
   emitter[1] = vehicleExplosionEmitter2;

   debris = turretDebris;
   debrisNum = 1;
   debrisNumVariance = 0;
   debrisPhiMin = 0;
   debrisPhiMax = 360;
   debrisThetaMin = 0;
   debrisThetaMax = 20;
   debrisVelocity = 18;
   debrisVelocityVariance = 3;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "7.0 8.0 7.0";
   camShakeAmp = "10.0 10.0 10.0";
   camShakeDuration = 0.75;
   camShakeRadius = 15.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 20;
   lightStartColor = "0.45 0.3 0.1";
   lightEndColor = "0 0 0";

   //impulse
   impulseRadius = 15;
   impulseForce = 1000;
   impulseVertical = 2000;

   //radius damage
   radiusDamage        = 30;
   damageRadius        = 8.0;

   //burn the players?
   playerBurnTime = 5000;

};

datablock ProjectileData(tankTurretExplosionProjectile)
{
   directDamage        = 0;
   radiusDamage        = 0;
   damageRadius        = 0;
   explosion           = tankTurretExplosion;

   directDamageType  = $DamageType::jeepExplosion;
   radiusDamageType  = $DamageType::jeepExplosion;

   explodeOnDeath		= 1;

   armingDelay         = 0;
   lifetime            = 10;
};


datablock DebrisData(tankDebris)
{
   emitters = "jeepDebrisTrailEmitter";

	shapeFile = "./tankDebris.dts";
	lifetime = 3.0;
	minSpinSpeed = -300.0;
	maxSpinSpeed = 300.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 1;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 2;
};

datablock ExplosionData(tankFinalExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 150;

   soundProfile = vehicleExplosionSound;
   
   emitter[0] = vehicleFinalExplosionEmitter3;
   emitter[1] = vehicleFinalExplosionEmitter2;

   particleEmitter = vehicleFinalExplosionEmitter;
   particleDensity = 20;
   particleRadius = 1.0;

   debris = tankDebris;
   debrisNum = 1;
   debrisNumVariance = 0;
   debrisPhiMin = 0;
   debrisPhiMax = 360;
   debrisThetaMin = 0;
   debrisThetaMax = 50;
   debrisVelocity = 15;
   debrisVelocityVariance = 3;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "7.0 8.0 7.0";
   camShakeAmp = "10.0 10.0 10.0";
   camShakeDuration = 0.75;
   camShakeRadius = 15.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 20;
   lightStartColor = "0.45 0.3 0.1";
   lightEndColor = "0 0 0";

   //impulse
   impulseRadius = 15;
   impulseForce = 1000;
   impulseVertical = 2000;

   //radius damage
   radiusDamage        = 30;
   damageRadius        = 8.0;

   //burn the players?
   playerBurnTime = 5000;

};

datablock ProjectileData(tankFinalExplosionProjectile)
{
   directDamage        = 0;
   radiusDamage        = 0;
   damageRadius        = 0;
   explosion           = tankFinalExplosion;

   directDamageType  = $DamageType::jeepExplosion;
   radiusDamageType  = $DamageType::jeepExplosion;

   explodeOnDeath		= 1;

   armingDelay         = 0;
   lifetime            = 10;
};

datablock DebrisData(tankShellDebris)
{
   emitters = "rocketTrailEmitter";

	shapeFile = "./emptywheel.dts";
	lifetime = 0.1;
	minSpinSpeed = -300.0;
	maxSpinSpeed = 300.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 0;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = false;

	gravModifier = 0;
};

datablock ExplosionData(tankShellExplosion)
{
   explosionShape = "";
   soundProfile = rocketExplodeSound;

   lifeTimeMS = 150;

   debris = tankShellDebris;
   debrisNum = 30;
   debrisNumVariance = 10;
   debrisPhiMin = 0;
   debrisPhiMax = 360;
   debrisThetaMin = 0;
   debrisThetaMax = 180;
   debrisVelocity = 140;
   debrisVelocityVariance = 50;

   particleEmitter = gravityRocketExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   emitter[0] = gravityRocketExplosionRingEmitter;
   emitter[1] = gravityRocketExplosionChunkEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "3.0 10.0 3.0";
   camShakeDuration = 0.5;
   camShakeRadius = 20.0;

   // Dynamic light
   lightStartRadius = 5;
   lightEndRadius = 20;
   lightStartColor = "1 1 0 1";
   lightEndColor = "1 0 0 0";

   damageRadius = 8;
   radiusDamage = 170;

   impulseRadius = 15;
   impulseForce = 5000;

   playerBurnTime = 5000;
};

AddDamageType("TankShellDirect",   '<bitmap:add-ons/Projectile_GravityRocket/rocket> %1',    '%2 <bitmap:add-ons/Projectile_GravityRocket/rocket> %1',1,1);
AddDamageType("TankShellRadius",   '<bitmap:add-ons/Projectile_GravityRocket/rocketRadius> %1',    '%2 <bitmap:add-ons/Projectile_GravityRocket/rocketRadius> %1',1,0);
datablock ProjectileData(tankShellProjectile)
{
   projectileShapeName = "./tankBullet.dts";
   directDamage        = 100;
   directDamageType = $DamageType::TankShellDirect;
   radiusDamageType = $DamageType::TankShellRadius;
   impactImpulse	   = 1000;
   verticalImpulse	   = 1000;
   explosion           = tankShellExplosion;
   particleEmitter     = rocketTrailEmitter;

   brickExplosionRadius = 5;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 50;             
   brickExplosionMaxVolume = 60;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 120;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   sound = rocketLoopSound;

   muzzleVelocity      = 120;
   velInheritFactor    = 1.0;

   armingDelay         = 0;
   lifetime            = 4000;
   fadeDelay           = 4000;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod = 1.0;

   hasLight    = true;
   lightRadius = 5.0;
   lightColor  = "1 0.5 0.0";

   explodeOnDeath = 1;

   uiName = "Tank Shell"; //naming it this way so it's next to the rocket in the alphabetized list
};