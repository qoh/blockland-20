//usage: registerInputEvent(%class, %eventName, %targetList, %adminOnly)
registerOutputEvent("GameConnection", "setCameraBrick", "string 200 156" TAB "string 200 156", 0);
registerOutputEvent("GameConnection", "setCameraNormal", "", 0);


//puts the player's camera at the given brick while retaining control of the player
function GameConnection::setCameraBrick(%client, %posBrickName, %targetBrickName)
{
   %camera = %client.camera;
   if(!isObject(%camera))
      return; //should never happen

   //translate name into brick object
   %posBrick = ("_" @ %posBrickName).getId();
   if(!isObject(%posBrick))
      return;
   %targetBrick = ("_" @ %targetBrickName).getId();
   if(!isObject(%targetBrick))
      return;

   //aim the camera at the target brick
   %pos = %posBrick.getPosition();
   %delta = vectorSub(%targetBrick.getPosition(), %pos);
   %deltaX = getWord(%delta, 0);
   %deltaY = getWord(%delta, 1);
   %deltaZ = getWord(%delta, 2);
   %deltaXYHyp = vectorLen(%deltaX SPC %deltaY SPC 0);

   %rotZ = mAtan(%deltaX, %deltaY) * -1; 
   %rotX = mAtan(%deltaZ, %deltaXYHyp);

   %aa = eulerRadToMatrix(%rotX SPC 0 SPC %rotZ); //this function should be called eulerToAngleAxis...

   %camera.setTransform(%pos SPC %aa);
   %camera.setFlyMode();
   %camera.mode = "Observer";

   //client controls camera
   %client.setControlObject(%camera);

   //camera controls player
   %player = %client.player;
   if(isObject(%player))
   {
      %camera.setControlObject(%player);
   }
   else
   {
      //do something to make the camera immobile?
      //%camera.setDollyMode(%camera.getPosition(), %camera.getPosition());
      %camera.setControlObject(%client.dummyCamera);
      
      //6802.camera.setDollyMode(6802.camera.getPosition(), 6802.camera.getPosition());
   }
}

//returns control back to player with normal camera
function GameConnection::setCameraNormal(%client)
{
   %camera = %client.camera;
   if(!isObject(%camera))
      return; //should never happen
   
   %player = %client.player;
   if(isObject(%player))
   {
      %client.setControlObject(%player);
   }
   else
   {
      //do something to make the mobile again?
      %camera.setControlObject(0);
      %camera.setFlyMode();
   }   
}

registerOutputEvent("MiniGame", "setCameraBrick", "string 200 156" TAB "string 200 156", 1);
registerOutputEvent("MiniGame", "setCameraNormal", "", 1);

function MiniGameSO::setCameraBrick(%mg, %posBrickName, %targetBrickName)
{
   //set camera position/target for every player
   for(%i = 0; %i < %mg.numMembers; %i++)
	{
		%cl = %mg.member[%i];
      %cl.setCameraBrick(%posBrickName, %targetBrickName);
   }
}  

function MiniGameSO::setCameraNormal(%mg, %posBrickName, %targetBrickName)
{
   //set normal camera for every player
   for(%i = 0; %i < %mg.numMembers; %i++)
	{
		%cl = %mg.member[%i];
      %cl.setCameraNormal();
   }
}  
