//server.cs -- for Support_legacyDoors, execute all things in here

function execLegacyDoors()
{
	exec( "Add-Ons/Support_LegacyDoors/server.cs");
}

%error = ForceRequiredAddOn( "Support_Doors" );

if( %error == $Error::AddOn_NotFound )
{
	error( "Support LegacyDoors : Support_Doors is missing somehow, what did you do?" );
}
else
{
	// main scripts
	exec( "./conversion.cs" );
}