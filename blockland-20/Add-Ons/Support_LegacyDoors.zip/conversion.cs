// conversion.cs contains everything relating to porting over jvs doors

// ContentTypesSO.addContentType("Add-Ons/JVS_DoorsPack0/types/CabinDoor.cs");

// overwrite jvs scriptObject and addContent function
// just put all variables into the blb datablock
// function eatJVSLunch()
// {	
	// new ScriptObject( ContentTypesSO )
	// {

	// };
// }

new ScriptObject( ContentTypesSO )
{
	
};

// 
function applyJVSVariables( %fileName, %basePath )
{
	//%scriptObject = new ScriptObject(){};
	
	%file = new FileObject();
	
	%brick = contentBrick;
	
	// make a huge string containing the datablock information, then eval it
	%category = "category = \"special\";";
	%subCategory = "subCategory = \"Legacy Doors\";";
	%dataBlockString = "datablock fxDTSBrickData( contentBrick ) {" SPC %category SPC %subCategory SPC "isDoor = 1; isJVS = 1;";
		
	if( %file.openForRead( %fileName ) )
	{
		while( !%file.isEOF() )
		{
			%line = %file.readLine();
			
			%length = strlen( %line );
			
			if( %length < 21 || strstr( %line, "$" ) == -1 )
				continue;
				
			// if we detect a comment continue
			if( strstr( %line, "//" ) == 0 )
				continue;
			
			// if we detect a comment after the variable remake the line
			%commentCheck = strstr( %line, "//" );
			if( %commentCheck > 30 )
				%line = getSubStr( %line, 0, %commentCheck );
			
			// if it's related to events just continue
			// if( strstr( %line, "event" ) > -1 )
				// continue;
			
			// strip it down
			%line = getSubStr( %line, 21, 128 );
			
			// add it to our brick datablock string
			// eval( %brick @ "." @ %line );
			
			%dataBlockString = %dataBlockString SPC %line;
		}
	}
	%file.close();
	%file.delete();
	
	// finish the string
	%dataBlockString = %dataBlockString SPC "};";
	
	// eval the final string
	eval( %dataBlockString );
	// special cases

	%brick.iconName = %basePath @ "icons/" @ %brick.datablockShape;
	
	%data = %brick.datablockBrick;
	
	%brick.setName( %data );
	return %data;
}

// replacement for aim sounds
datablock AudioProfile( contentSoundStartLegacyDoor )
{
	filename = "Add-Ons/Support_legacyDoors/doorLegacyOpen.wav";
	description = AudioClose3d;
	preload = true;
};
datablock AudioProfile( contentSoundStopLegacyDoor )
{
	filename = "Add-Ons/Support_legacyDoors/doorLegacyClose.wav";
	description = AudioClose3d;
	preload = true;
};

// particle for the emitter
if(!isObject(contentParticleDebris))
{
	datablock ParticleData(contentParticleDebris)
	{
		dragCoefficient = 3.0;
		windCoefficient = 0.0;
		gravityCoefficient = -0.5;
		inheritedVelFactor = 0.0;
		constantAcceleration = 0.0;
		lifetimeMS = 500;
		lifetimeVarianceMS = 150;
		spinSpeed = 10.0;
		spinRandomMin = -50.0;
		spinRandomMax = 50.0;
		useInvAlpha = true;
		animateTexture = false;
		textureName = "base/data/particles/cloud";
		colors[0] = "0.0 0.0 0.0 0.0";
		colors[1] = "0.0 0.0 0.0 0.250";
		colors[2] = "0.0 0.0 0.0 0.0";
		sizes[0] = 1.50;
		sizes[1] = 2.50;
		sizes[2] = 3.50;
		times[0] = 0.0;
		times[1] = 0.1;
		times[2] = 1.0;
	};
}

// emitter for the explosions
if( !isObject( contentEmitterDebris ) )
{
	datablock ParticleEmitterData(contentEmitterDebris)
	{
		ejectionPeriodMS = 90;
		periodVarianceMS = 0;
		ejectionVelocity = 0.0;
		velocityVariance = 0.0;
		ejectionOffset = 1.0;
		thetaMin = 0;
		thetaMax = 0;
		phiReferenceVel = 0;
		phiVariance = 360;
		overrideAdvance = false;
		particles = "contentParticleDebris";
	};
}

// makes a door out of the variables from jvs, %file : "Add-Ons/JVS_DoorsPack0/types/CabinDoor.cs"
function ContentTypesSO::addContentType( %this, %file )
{
	deleteVariables("$JVS::Content::Type::*");
	%filePath = filePath(%file);
	%typesCheck = getSubStr( %filePath, strLen( %filePath ) - 6, 6 );
	
	if( !isFile(%file) || %typesCheck !$= "/types")
	{
		error( "not valid door file" );
		return;
	}

	
	%basePath = getSubStr(%filePath,0,strLen(%filePath) - 5);
	%name = fileBase(%file);
	//exec(%file);
		
	// might have to search through file before making blb to get datablock, uiName, brickfile, and iconName
	// do initial pass through the door cs file
	// %brickSO = initialJVSRead( %file );
	
	// let's figure out the information we need for the blbs creation
	// %dataBlock = %brickSO.datablockBrick;
	// %iconName = %basePath @ "icons/" @ %brickSO.datablockShape;
	// %brickFile = %brickSO.brickFile;
	// %uiName = %brickSO.uiName;
	
	// delete the brickSO
	// %brickSO.delete();
	
	// hack to see if this is causing the problem
	// new ScriptObject( contentBrick ){};
	// %contentSOW = applyJVSVariables( %file, %basePath );
	
	// %brick.iconName = %basePath @ "icons/" @ %brick.datablockShape;
	
	// %data = %brick.datablockBrick;
	
	// %contentSOW.setName( "" );
	
	// make the blb file
	// datablock fxDTSBrickData( contentBrick )
	// {
		// brickFile = %brickFile;
		// category = "special";
		// subCategory = "Legacy Doors";
		// uiName = %uiName;
		// iconName = %iconName;
		
		// hacks to test 
		// brickFile = %contentSOW.brickFile;
		// uiName = %contentSOW.uiName;
		// iconName = %contentSOW.iconName;
		
		// brickFile = "Add-Ons/JVS_DoorsPack0/bricks/1_4_15.blb";
		// uiName = "Cell Door";
		
		// isDoor = 1;
		// isOpen = 0;
		// open = "brickDoorBasicOpenData";
		
		// isJVS = 1;
	// };
	
	// %contentSOW.delete();
	
	%data = applyJVSVariables( %file, %basePath );
	
	%shape = %data.datablockShape;
	%shapeColliding = %data.datablockShapeColliding;
	
	if( strlen( %shapeColliding ) )
		%shapeFile = %basePath @ "shapes/" @ %shapeColliding @ ".dts";
	else
		%shapeFile = %basePath @ "shapes/" @ %data.datablockShape @ ".dts";
	
	// find out if it's a switch
	%subCat = strlwr( %data.brickSubcategory );
	
	if( strstr( %subCat, "switch" ) >= 0 )
		%data.subCategory = "Legacy Switches";
	
	// loop through events we need one more piece of information
	// we need to figure out how this door operates, how fast it closes, if it is a toggle
	// this can be attained by looking at the onContentStarted event
	// if it has a matching contentStop event at the end we can figure out how it operates
	for( %a = 0; %a < %data.eventCount; %a++ )
	{
		// eventInput[4] = "\"onContentStarted\"";
		// eventOutput[4] = "\"contentStop\"";
		// eventDelay
		if( %data.eventInput[ %a ] $= "\"onContentStarted\"" && %data.eventOutput[ %a ] $= "\"contentStop\"" )
		{
			%delay = %data.eventDelay[ %a ];
			
			%foundDelay = 1;
			
			%data.doorDelay = %delay;
			// echo( "Door" SPC %data.getName() SPC "Found Delay of" SPC %delay );
		}
		
		// look through events to find out how to collide with this object
		// if we don't find anything assume we collide with it
		// eventInput[1] = "\"onContentStart\"";
		// eventTarget[1] = "\"Self\"";
		// eventOutput[1] = "\"setColliding\"";
		// eventParameter[1 @ "_" @ 0] = 0;

		// should I add started/stop as well?
		
		// onContentCreated
		if( %data.eventInput[ %a ] $= "\"onContentCreated\"" && %data.eventOutput[ %a ] $= "\"setColliding\"" )
		{
			%data.colCreated = %data.eventParameter[ %a @ "_" @ 0];
			
			%colCreatedSet = 1;
		}
		
		// onContentStart
		if( ( %data.eventInput[ %a ] $= "\"onContentStart\"" || %data.eventInput[ %a ] $= "\"onContentStarted\"" ) && %data.eventOutput[ %a ] $= "\"setColliding\"" )
		{
			%data.colOpen = %data.eventParameter[ %a @ "_" @ 0];
			
			%colOpenSet = 1;
		}
		
		// onContentStopped
		if( ( %data.eventInput[ %a ] $= "\"onContentStopped\"" || %data.eventInput[ %a ] $= "\"onContentStop\"" ) && %data.eventOutput[ %a ] $= "\"setColliding\"" )
		{
			%data.colClosed = %data.eventParameter[ %a @ "_" @ 0];
			
			%colClosedSet = 1;
		}
	}
	// check if variables haven't been set
	if( !%colCreatedSet )
		%data.colCreated = 1;
	
	if( !%colOpenSet )
		%data.colOpen = 1;
		
	if( !%colClosedSet )
		%data.colClosed = 1;
	
	
	// if we haven't found a delay we'll handle this differently
	if( !%foundDelay )
	{
		// echo( "Door" SPC %data.getName() SPC "No Delay switch?" );
		%data.isSwitch = 1;
	}
	
	// the actual door dts shape
	datablock StaticShapeData( contentShape )
	{
		shapefile = %shapeFile;
	};

	contentShape.setName( %shape );
	
	// start and stop sounds
	%stopSound = %data.datablockSoundStop;
	%stopSoundFile = %basePath @ "sounds/" @ %stopSound @ ".wav";
	
	// echo( %name );
	
	if( !isObject( %stopSound ) )
	{
		datablock AudioProfile( contentStopSound )
		{
			filename = %stopSoundFile;
			description = AudioClose3d;
			preload = true;
		};

		contentStopSound.setName( %stopSound );
	}

	%startSound = %data.datablockSoundStart;
	%startSoundFile = %basePath @ "sounds/" @ %startSound @ ".wav";
	
	if( !isObject( %startSound ) )
	{
		datablock AudioProfile( contentStartSound )
		{
			filename = %startSoundFile;
			description = AudioClose3d;
			preload = true;
		};

		contentStartSound.setName( %startSound );
	}

	// if we have aim sounds, use the replacement sounds
	if( %stopSound $= "contentSoundStopAIM" )
	{
		%data.datablockSoundStop = contentSoundStopLegacyDoor;
		%data.soundDelayStop = 300;
	}
		
	if( %startSound $= "contentSoundStartAIM" )
		%data.datablockSoundStart = contentSoundStartLegacyDoor;
	
	// this is nice to look at rather than nothing, but i'm unsure if this is worth it
	// create the explosions, projectiles and debris needed
	%debris = %data.datablockDebris;
	%debrisFile = %debrisFile = %basePath @ "shapes/" @ %debris @ ".dts";
	
	if( isObject( %debris ) )
	{
		%debris = %debris @ "DebrisDup";
	}
	
	datablock DebrisData(contentDebris)
	{
		baseRadius = "1";
		bounceVariance = "0";
		className = "DebrisData";
		elasticity = "0.5";
		explodeOnMaxBounce = "0";
		fade = "1";
		friction = "0.2";
		gravModifier = "2";
		ignoreWater = "1";
		lifetime = "2";
		lifetimeVariance = "0";
		maxSpinSpeed = "200";
		minSpinSpeed = "-400";
		numBounces = "3";
		render2D = "0";
		shapeFile = %debrisFile;
		snapOnMaxBounce = "0";
		staticOnMaxBounce = "1";
		terminalVelocity = "0";
		useRadiusMass = "0";
		velocity = "0";
		velocityVariance = "0";
		emitters[0] = "contentEmitterDebris";
	};

	contentDebris.setName(%debris);
	
	%explosion = %data.datablockExplosion;
	
	datablock ExplosionData(contentExplosion)
	{
		className = "ExplosionData";
		Debris = %debris;
		debrisNum = "1";
		debrisNumVariance = "0";
		debrisPhiMax = "360";
		debrisPhiMin = "0";
		debrisThetaMax = "85";
		debrisThetaMin = "40";
		debrisVelocity = "14";
		debrisVelocityVariance = "3";
		delayMS = "0";
		delayVariance = "0";
		explosionScale = "1 1 1";
		faceViewer = "1";
		lifetimeMS = "150";
		lifetimeVariance = "0";
		offset = "0";
		particleDensity = "10";
		particleRadius = "1";
		playSpeed = "1";
		shakeCamera = "0";
		damageRadius = "0";
		impulseForce = "0";
		impulseRadius = "0";
		radiusDamage = "0";
	};

	contentExplosion.setName(%explosion);

	%projectile = %data.datablockProjectile;
	
	datablock ProjectileData(contentProjectile)
	{
		directDamage = 0;
		radiusDamage = 0;
		damageRadius = 0;
		explosion = %explosion;
		directDamageType = $DamageType::jeepExplosion;
		radiusDamageType = $DamageType::jeepExplosion;
		explodeOnDeath = 1;
		armingDelay = 0;
		lifetime = 10;
	};

	contentProjectile.setName(%projectile);
	
	// contentBrick.brickFile = %brickFile;
	// contentBrick.category = "special";
	// contentBrick.subCategory = "Doors";
	// contentBrick.uiName = %uiName;
	// contentBrick.iconName = %iconName;
	
	// contentBrick.setName( %dataBlock );
}

// method to color the dts shape
function fxDTSBrick::contentColor( %obj, %color )
{
	// ghost shape check
	%ghostShape = %obj.ghostShape;
	
	if( isObject( %ghostShape ) )
	{
		// paint the ghost shape
		%color = %obj.getColorId();
		%setcolor = getColorIDTable( %color );
		
		// echo( %color SPC %setcolor );
		
		%r = getWord( %setcolor, 0 );
		%g = getWord( %setcolor, 1 );
		%b = getWord( %setcolor, 2 );
		%obj.ghostShape.setNodeColor( "ALL",%r SPC %g SPC %b SPC 1 );
	}
	
	// main shape check
	%shape = %obj.shape;
	
	if( !isObject( %shape ) )
		return;
	
	%data = %obj.getDataBlock();
	
	%color = getColorIDTable( %obj.getColorId() );
	%r = getWord(%color,0);
	%g = getWord(%color,1);
	%b = getWord(%color,2);
	
	%color = %r SPC %g SPC %b SPC 1;
	%black25 = %r * 0.75 SPC %g * 0.75 SPC %b * 0.75 SPC 1;
	%black50 = %r * 0.5 SPC %g * 0.5 SPC %b * 0.5 SPC 1;
	%black75 = %r * 0.25 SPC %g * 0.25 SPC %b * 0.25 SPC 1;

	for( %i = 0;%i < %data.nodeCount; %i++ )//ContentTypesSO.nodeCount[%contentTypeID];%i++)
	{
		%nodecolor = %data.nodeColor[ %i ];// ContentTypesSO.nodeColor[%i @ "_" @ %contentTypeID];
		%nodename = %data.nodeName[ %i ];// ContentTypesSO.nodeName[%i @ "_" @ %contentTypeID];

		if(%nodecolor $= "black25")
		{
			%shape.setNodeColor(%nodename,%black25);
		}
		else if(%nodecolor $= "black50")
		{
			%shape.setNodeColor(%nodename,%black50);
		}
		else if(%nodecolor $= "black75")
		{
			%shape.setNodeColor(%nodename,%black75);
		}
		else if(%nodecolor $= "color")
		{
			%shape.setNodeColor(%nodename,%color);
		}
		else
		{
			%shape.setNodeColor(%nodename,%nodecolor);
		}
	}
}

function fxDTSBrick::contentCreate( %obj )
{
	// double check to make sure this is a port brick
	// if( !%obj.getDataBlock()isJVS )
		// return;	
	
	%data = %obj.getDataBlock();
	
	%obj.setRendering( 0 );
	
	// set up collision
	if( !%data.colCreated )
		%obj.setColliding( 0 );
	
	if( isObject( %obj.shape ) )
	{
		%obj.shape.delete();
	}

	%angleID = %obj.getAngleID();
	%datablock = %data.datablockShape;//ContentTypesSO.getDatablockShapeCollidingFromID(%contentTypeID);

	// create the door shape
	%shape = new StaticShape()
	{
		datablock = %datablock;
		spawnBrick = %obj;
	};

	if( !isObject( %shape ) )
		return;
		
	MissionCleanup.add( %shape );
	%obj.shape = %shape;
	%shape.state = 0;

	// color the brick
	%obj.contentColor();

	%pos = %obj.position;

	// fun fact the function in bl "eulerToQuat", is actually misnamed
	// correct name is eulerToAxis, but now it's too late to rename it
	// dooooooooooooooooomed
	if(%angleID == 2)
	{
		%shape.setTransform( %pos SPC eulerToQuat("0 0 270") );
	}
	else if(%angleID == 0)
	{
		%shape.setTransform( %pos SPC eulerToQuat("0 0 90") );
	}
	else if(%angleID == 1)
	{
		%shape.setTransform( %pos SPC eulerToQuat("0 0 0") );
	}
	else if(%angleID == 3)
	{
		%shape.setTransform( %pos SPC eulerToQuat("0 0 180") );
	}

	%shape.transform = %shape.getTransform();
}

// collision function, so we can enable and disable collision correctly, and avoid error callbacks
function fxDTSBrick::doorJVSSetCollision( %obj, %col )
{
	if( !isObject( %obj ) || !isObject( %obj.shape ) )
	{
		echo( "no brick or shape present returning" );
		return;
	}
	
	%data = %obj.getDataBlock();
	
	if( !%obj.getDataBlock().isSwitch )
		%obj.setRaycasting( %col );
		
	%obj.setColliding( %col );
}

// handles opening of door
function fxDTSBrick::doorJVSOpen( %obj, %ccw, %client )
{
	// if either the brick or the dts shape is gone return
	// also if door is open don't re-open it
	if( !isObject( %obj ) || !isObject( %obj.shape ) || %obj.dIsOpen )
		return;
		
	cancel( %obj.dDoorSchedule );
	
	// onDoorOpen event
	%obj.onDoorOpen( %client );
	
	%data = %obj.getDataBlock();
	
	// detect if clockwise or counter
	if( %ccw )
		%obj.shape.playThread( 0, %data.animationNameStartCCW );
	else
		%obj.shape.playThread( 0, %data.animationNameStartCW );
		
	%obj.dIsOpen = 1;
	%obj.dOpenDir = %ccw;
	
	%obj.dDelay = getSimTime() + %data.animationLengthStart;
	
	if( %data.colOpen )
		%obj.doorJVSSetCollision( 1 );
	else
		%obj.doorJVSSetCollision( 0 );
}

function fxDTSBrick::doorJVSClose( %obj, %ccw, %client )
{
	// if either the brick or the dts shape is gone return
	// if door is closed don't close it
	if( !isObject( %obj ) || !isObject( %obj.shape ) || !%obj.dIsOpen )
		return;
	
	cancel( %obj.dDoorSchedule );
	cancel( %obj.doorToggleSchedule );
	
	// onDoorClose event
	%obj.onDoorClose( %client );
	
	// %obj.doorIsToggling = 0;
	
	%data = %obj.getDataBlock();
	
	%obj.dIsOpen = 0;
	
	// detect if clockwise or counter
	if( %ccw )
		%obj.shape.playThread( 0, %data.animationNameStopCCW );
	else
		%obj.shape.playThread( 0, %data.animationNameStopCW );
		
	%obj.dDelay = getSimTime() + %data.animationLengthStop;
	
	if( %data.colClosed )
		%obj.dDoorSchedule = %obj.schedule( %data.animationLengthStop, doorJVSSetCollision, 1 );
	else
		%obj.dDoorSchedule = %obj.schedule( %data.animationLengthStop, doorJVSSetCollision, 0 );
}

// legacy door event function, for now a separate function
function fxDTSBrick::doorJVS( %obj, %rot, %client )
{
	// get the datablock and check if this is a door
	%data = %obj.getDataBlock();
	
	// if( getSimTime() < %obj.dDelay )
		// return;
	
	// if it's not a door return
	// still unsure about the dDelay
	if( !%data.isDoor || getSimTime() < %obj.dDelay )
		return;

	// %obj.lastDoorClient = %client;
	
	// door states
	%toggleCW = 0;
	%toggleCCW = 1;
	%openCW = 2;
	%openCCW = 3;
	%close = 4;
	
	if( %rot == %toggleCW )
	{
		// toggle things, play the animation, adjust collision
		if( %data.isSwitch )
		{
			if( %obj.dIsOpen )
				%obj.doorJVSClose( 0, %client );
			else
				%obj.doorJVSOpen( 0, %client );
		}
		else
		{
			// if door is open but toggle is called close it
			if( %obj.dIsOpen )
			{
				// cancel( %obj.doorToggleSchedule );
				%obj.doorJVSClose( 0, %client );
				return;
			}
			
			%obj.doorJVSOpen( 0, %client );
			
			// %obj.doorIsToggling = 1;
			
			cancel( %obj.doorToggleSchedule );
			%obj.doorToggleSchedule = %obj.schedule( %data.doorDelay + %data.animationLengthStart, doorJVSClose, 0, %client );
		}
	}
	else if( %rot == %toggleCCW )
	{
		// same as before but opposite way
		if( %data.isSwitch )
		{
			if( %obj.dIsOpen )
				%obj.doorJVSClose( 1, %client );
			else
				%obj.doorJVSOpen( 1, %client );
		}
		else
		{
			// if door is open but toggle is called close it
			if( %obj.dIsOpen )
			{
				// cancel( %obj.doorToggleSchedule );
				%obj.doorJVSClose( 1, %client );
				return;
			}
			
			%obj.doorJVSOpen( 1, %client );
			
			cancel( %obj.doorToggleSchedule );
			%obj.doorToggleSchedule = %obj.schedule( %data.doorDelay + %data.animationLengthStart, doorJVSClose, 1, %client );
		}
	}
	else if( %rot == %openCW )
	{
		// open clockwise
		%obj.doorJVSOpen( 0, %client );
	}
	else if( %rot == %openCCW )
	{
		// open clockwise
		%obj.doorJVSOpen( 1, %client );
	}
	else if( %rot == %close )
	{
		%obj.doorJVSClose( %obj.dOpenDir, %client );
	}
}

// registerOutputEvent( "fxDTSBrick", "doorJVS", "list ToggleCW 0 ToggleCCW 1 OpenCW 2 OpenCCW 3 Close 4", 1 );

// can't seem to find dts shapes for some reason
function detectDoorDTS()
{
	%player = findClientByName( rot ).player;

	%pos = %player.getEyePoint();
	%vec = vectorScale( %player.getEyeVector(), 8 );
	
	%endPos = vectorAdd( %pos, %vec );
	
	%type = $TypeMasks::StaticShapeObjectType;//$TypeMasks::StaticObjectType;
	
	%obj = containerRayCast( %pos, %endPos, %type, %player );
	
	echo( %obj );
	
}

package legacyDoorSupportPackage
{	
	// ----- 

	function ServerCmdPlantBrick( %client )
	{
		%ghostShape = %client.ghostShape;
	
		if( !isObject( %ghostShape ) )
			return parent::ServerCmdPlantBrick( %client );
	
		%ghostShape.oldTrans = %ghostShape.getTransform();
		
		%ghostShape.setTransform( "0 0 -1000" );
		
		%retVal = parent::ServerCmdPlantBrick( %client );
		
		%ghostShape.setTransform( %ghostShape.oldTrans );
		
		return %retVal;
	}
	
	// ghost brick things
	function fxDTSBrick::setTransform( %obj, %transform )
	{
		Parent::setTransform( %obj,%transform );
		
		// echo( "Moving ghost brick?" SPC %obj );
		%obj.contentGhostBrickCheck();
	}
	
	function fxDTSBrick::contentGhostBrickCheck( %obj )
	{
		// check if we exist and we're not planted	
		if( !isObject( %obj ) || %obj.isPlanted )
			return;
		
		%data = %obj.getDataBlock();
		
		%client = %obj.getGroup().client;
		
		// if we're not a door datablock then return
		if( !%data.isJVS )
		{
			// check if we have a ghost shape somehow
			if( isObject( %obj.ghostShape ) )
			{
				%obj.ghostShape.delete();
				%client.ghostShape = "";
			}
			
			return;
		}
		
		// alert our 
		
		// get position and rotation
		%pos = %obj.position;
		%angleID = %obj.getAngleID();
		
		// if we don't have a ghost shape create it, if we do have one but it doesn't match our current shape switch it
		if( !isObject( %obj.ghostShape ) )
		{
			%dataBlock = %data.datablockShape;//ContentTypesSO.getDatablockShapeFromID(%contentTypeID);

			%obj.ghostShape = new StaticShape()
			{
				dataBlock = %dataBlock;
			};
			
			missionCleanup.add( %obj.ghostShape );
		}
		else if( isObject( %obj.ghostShape ) && %obj.ghostShape.getDataBlock().getName() !$= %data.datablockShape )
		{
			// echo( "switching datablock" );
			%obj.ghostShape.setDataBlock( %data.datablockShape );
			// %obj.ghostShape.delete();
			
			// %dataBlock = %data.datablockShape;

			// %obj.ghostShape = new StaticShape()
			// {
				// dataBlock = %dataBlock;
			// };
			
			// missionCleanup.add( %obj.ghostShape );
		}
		
		%client.ghostShape = %obj.ghostShape;
		
		// paint the ghost shape // moved to contentColor function
		%obj.contentColor();
		// %r = getWord( %setcolor, 0 );
		// %g = getWord( %setcolor, 1 );
		// %b = getWord( %setcolor, 2 );
		// %obj.ghostShape.setNodeColor( "ALL",%r SPC %g SPC %b SPC 1 );
		
		// handle rotation
		if(%angleID == 2)
			%rot = eulerToQuat("0 0 270");
		else if(%angleID == 3)
			%rot = eulerToQuat("0 0 180");
		else if(%angleID == 0)
			%rot = eulerToQuat("0 0 90");
		else
			%rot = eulerToQuat("0 0 0");

		%obj.ghostShape.setTransform( %pos SPC %rot );
		
		return;
		
			// datablockBrick
				if(isObject(%obj.ghostShape) && %obj.dataBlock $= ContentTypesSO.getDatablockShapeFromID(%contentTypeID))
				{
					%pos = %obj.position;
					%angleID = %obj.getAngleID();

					if(%angleID == 2)
					{
						%rot = contentEulerToAxis("0 0 270");
					}
					else if(%angleID == 3)
					{
						%rot = contentEulerToAxis("0 0 180");
					}
					else if(%angleID == 0)
					{
						%rot = contentEulerToAxis("0 0 90");
					}
					else
					{
						%rot = contentEulerToAxis("0 0 0");
					}

					%obj.ghostShape.setTransform(%pos SPC %rot);
				}
				else
				{
					if(isObject(%obj.ghostShape))
					{
						%obj.ghostShape.delete();
					}

					%obj.ghostShape = "";
					%pos = %obj.position;
					%angleID = %obj.getAngleID();

					if(%angleID == 2)
					{
						%rot = contentEulerToAxis("0 0 270");
					}
					else if(%angleID == 3)
					{
						%rot = contentEulerToAxis("0 0 180");
					}
					else if(%angleID == 0)
					{
						%rot = contentEulerToAxis("0 0 90");
					}
					else
					{
						%rot = contentEulerToAxis("0 0 0");
					}

					%dataBlock = ContentTypesSO.getDatablockShapeFromID(%contentTypeID);

					%obj.ghostShape = new StaticShape()
					{
						dataBlock = %dataBlock;
					};

					%obj.ghostShape.setTransform(%pos SPC %rot);
					%color = %obj.getColorId();
					%setcolor = getColorIDTable(%color);
					%r = getWord(%setcolor,0);
					%g = getWord(%setcolor,1);
					%b = getWord(%setcolor,2);
					%obj.ghostShape.setNodeColor("ALL",%r SPC %g SPC %b SPC 1);
				}
				
		if(isObject(%obj) && %obj.isPlanted)
		{
			if(isObject(%obj.ghostShape))
			{
				%obj.ghostShape.delete();
			}

			%obj.ghostShape = "";
		}
	}
	
	// intercept when the color changes so we can alter the dts doors color
	function fxDTSBrick::onColorChange( %obj )
	{
		%data = %obj.getDataBlock();
		
		if( %data.isDoor && %data.isJVS )
			%obj.contentColor();
		
		return parent::onColorChange( %obj );
	}

	function fxDTSBrickData::onFakeDeath( %this, %obj )
	{
		if( %this.isDoor && %this.isJVS && isObject( %obj.shape ) )
		{
			//%obj.shape.hideNode( "ALL" );
			%obj.shape.delete();
			
			%p = new Projectile()
			{
				dataBlock = %this.datablockProjectile;// ContentTypesSO.getDatablockProjectileFromID(%contentTypeID);
				initialPosition = %obj.getPosition();
				initialVelocity = "0 0 1";
				//client = %client;
				//sourceClient = %client;
			};
			// %obj.setRendering( 1 );
		}
		
		return parent::onFakeDeath( %this, %obj );
	}
	
	function fxDTSBrick::onClearFakeDeath( %obj )
	{
		%this = %obj.getDataBlock();
		
		if( %this.isDoor && %this.isJVS )
		{
			//%obj.shape.schedule( 2000, unHideNode, "ALL" );
			//%obj.setRendering( 1 );
			//%obj.schedule( 600, contentCreate );
			%obj.contentCreate();
			//%obj.contentCreate();
		}
		
		return parent::onClearFakeDeath( %obj );
	}
	
	// door removal functions
	function fxDTSBrick::onDeath( %obj )
	{
		%data = %obj.getDataBlock();
		
		if( %data.isDoor && %data.isJVS && isObject( %obj.shape ) )
			%obj.shape.delete();
		
		return parent::onDeath( %obj );
	}
	
	function fxDTSBrick::onRemove( %obj )
	{
		%data = %obj.getDataBlock();
		
		if( %data.isDoor && %data.isJVS )
		{
			if( isObject( %obj.shape ) )
				%obj.shape.delete();
			
			if( isObject( %obj.ghostShape ) )
			{
				%obj.ghostShape.delete();
				// 
			}
		}
		
		return parent::onRemove( %obj );
	}
	
	// converts old jvs saves to new format
	function outputEvent_GetOutputEventIdx( %type, %output )
	{
		if( %type $= "fxDTSBrick" && %output $= "contentStart" )
			return outputEvent_GetOutputEventIdx( "fxDTSBrick","door" );
		
		return parent::outputEvent_GetOutputEventIdx( %type, %output );
	}
};
activatePackage( legacyDoorSupportPackage );

// return here so we don't error out
return;

				if(!isObject(%stopSound))
				{
					datablock AudioProfile(contentStopSound)
					{
						filename = %stopSoundFile;
						description = AudioClose3d;
						preload = true;
					};

					contentStopSound.setName(%stopSound);
				}
				
				if(!isObject(%startSound))
				{
					datablock AudioProfile(contentStartSound)
					{
						filename = %startSoundFile;
						description = AudioClose3d;
						preload = true;
					};

					contentStartSound.setName(%startSound);
				}
				
				if(!isObject(%brick))
				{
					datablock fxDTSBrickData(contentBrick)
					{
						brickFile = %brickFile;
						category = "JVS";
						subCategory = %subCategory;
						uiName = %uiName;
						iconName = %uiFile;
						collisionShapeName = %brickCollisionFile;
					};

					contentBrick.setName(%brick);
				}
				
				if(!isObject(%shape))
				{
					datablock StaticShapeData(contentShape)
					{
						shapefile = %shapeFile;
					};

					contentShape.setName(%shape);
				}
				
				if(!isObject(%debris))
				{
					datablock DebrisData(contentDebris)
					{
						baseRadius = "1";
						bounceVariance = "0";
						className = "DebrisData";
						elasticity = "0.5";
						explodeOnMaxBounce = "0";
						fade = "1";
						friction = "0.2";
						gravModifier = "2";
						ignoreWater = "1";
						lifetime = "2";
						lifetimeVariance = "0";
						maxSpinSpeed = "200";
						minSpinSpeed = "-400";
						numBounces = "3";
						render2D = "0";
						shapeFile = %debrisFile;
						snapOnMaxBounce = "0";
						staticOnMaxBounce = "1";
						terminalVelocity = "0";
						useRadiusMass = "0";
						velocity = "0";
						velocityVariance = "0";
						emitters[0] = "contentEmitterDebris";
					};

					contentDebris.setName(%debris);
				}

				if(!isObject(%explosion))
				{
					datablock ExplosionData(contentExplosion)
					{
						className = "ExplosionData";
						Debris = %debris;
						debrisNum = "1";
						debrisNumVariance = "0";
						debrisPhiMax = "360";
						debrisPhiMin = "0";
						debrisThetaMax = "85";
						debrisThetaMin = "40";
						debrisVelocity = "14";
						debrisVelocityVariance = "3";
						delayMS = "0";
						delayVariance = "0";
						explosionScale = "1 1 1";
						faceViewer = "1";
						lifetimeMS = "150";
						lifetimeVariance = "0";
						offset = "0";
						particleDensity = "10";
						particleRadius = "1";
						playSpeed = "1";
						shakeCamera = "0";
						damageRadius = "0";
						impulseForce = "0";
						impulseRadius = "0";
						radiusDamage = "0";
					};

					contentExplosion.setName(%explosion);
				}

				if(!isObject(%projectile))
				{
					datablock ProjectileData(contentProjectile)
					{
						directDamage = 0;
						radiusDamage = 0;
						damageRadius = 0;
						explosion = %explosion;
						directDamageType = $DamageType::jeepExplosion;
						radiusDamageType = $DamageType::jeepExplosion;
						explodeOnDeath = 1;
						armingDelay = 0;
						lifetime = 10;
					};

					contentProjectile.setName(%projectile);
				}