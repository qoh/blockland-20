/////////////////////
// BloodAndGore.cs //
// / / / / / / / / //
//  Version: 1.5   //
/////////////////////

datablock AudioProfile(goryExplosionSound)
{
   filename    = "./splat.wav";
   description = AudioClosest3d;
   preload = false;
};

datablock ParticleData(goreParticle)
{
   dragCoefficient      = 6;
   gravityCoefficient   = 0.6;
   inheritedVelFactor   = 0.5;
   constantAcceleration = 0;
   lifetimeMS           = 2000;
   lifetimeVarianceMS   = 1000;
   textureName          = "./pain";
   spinSpeed      = 0;
   spinRandomMin  = -100;
   spinRandomMax   = 100;
   colors[0]     = "1 0 0 1";
   colors[1]     = "0.8 0 0 0.9 ";
   colors[2]     = "0.5 0 0 0";
   sizes[0]      = 1;
   sizes[1]      = 2.5;
   sizes[2]      = 0.65;
   times[1] = 0.5;
   times[2] = 1;
   useInvAlpha = true;
};
datablock ParticleEmitterData(goreEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   ejectionVelocity = 10;
   velocityVariance = 5;
   ejectionOffset   = 0.25;
   thetaMin         = 5;
   thetaMax         = 105;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "goreParticle";

   uiName = "Gore";
};

datablock ParticleData(smallBloodParticle)
{
   dragCoefficient = 3;
   gravityCoefficient = 0.5;
   inheritedVelFactor = 0.3;
   constantAcceleration = 0;
   lifetimeMS         = 1000;
   lifetimeVarianceMS = 250;
   textureName = "base/data/particles/dot";
   spinSpeed     = 0;
   spinRandomMin = -20;
   spinRandomMax = 20;
   colors[0] = "0.6 0 0 1";
   colors[1] = "0.5 0 0 0.9 ";
   colors[2] = "0.4 0 0 0";
   sizes[0] = 0.06;
   sizes[1] = 0.09;
   sizes[2] = 0.04;
   times[1] = 0.5;
   times[2] = 1;
   useInvAlpha = true;
};

datablock ParticleEmitterData(smallBloodEmitter)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;
   ejectionVelocity = 2;
   velocityVariance = 1.2;
   ejectionOffset   = 0;
   thetaMin = 0;
   thetaMax = 180;
   phiReferenceVel = 0;
   phiVariance     = 360;
   overrideAdvance = false;
   lifetimeMS = 3500;
   particles = "smallBloodParticle";

   uiName = "Bleed";
};

datablock ParticleData(bigBloodParticle)
{
   dragCoefficient      = 2;
   gravityCoefficient   = 0.7;
   inheritedVelFactor   = 0.4;
   constantAcceleration = 0;
   lifetimeMS         = 750;
   lifetimeVarianceMS = 250;
   textureName = "base/data/particles/cloud";
   spinSpeed     = 0;
   spinRandomMin = -400;
   spinRandomMax = 400;
   colors[0] = "0.7 0 0 1";
   colors[1] = "0.6 0 0 0.9 ";
   colors[2] = "0.45 0 0 0";
   sizes[0]  = 0.2;
   sizes[1]  = 0.25;
   sizes[2]  = 0.17;
   times[1]  = 0.5;
   times[2]  = 1;
   useInvAlpha = true;
};

datablock ParticleEmitterData(bigBloodEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 5;
   velocityVariance = 1.5;
   ejectionOffset   = 0.2;
   thetaMin         = 0;
   thetaMax         = 105;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "bigBloodParticle";

   uiName = "Blood";
};

datablock DebrisData(boneChunkDebris)
{
   emitters = smallBloodEmitter;

   shapeFile = "./chunk.dts";
   lifetime = 10;
   lifetimeVariance = 2;
   minSpinSpeed = -300;
   maxSpinSpeed = 300;
   elasticity = 0.4;
   friction = 0.1;
   numBounces = 10;
   staticOnMaxBounce = true;
   fade = true;
   gravModifier = 0.8;
};
datablock DebrisData(boneChunkDebris2 : boneChunkDebris)
{
   shapeFile = "./hand.dts";
};
datablock DebrisData(boneChunkDebris3 : boneChunkDebris)
{
   shapeFile = "./shoe.dts";
};
datablock ExplosionData(gorySubExplosion1) //Gotta make sub-explosions first because an explosion has to exist to be a part of another explosion...
{
   lifetimeMS = 33;
   particleEmitter = "";
   debris = boneChunkDebris2;
   debrisNum              = 2;
   debrisNumVariance      = 0;
   debrisPhiMin           = 0;
   debrisPhiMax           = 360;
   debrisThetaMin         = 5;
   debrisThetaMax         = 105;
   debrisVelocity         = 10;
   debrisVelocityVariance = 4;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;

   lightStartRadius = 0;
   lightEndRadius = 0;

   impulseRadius = 100;
   impulseForce = 100;

   radiusDamage = 0;
   damageRadius = 0;

   uiName = ""; //This will spawn alongside Gory Explosion if that is used on a brick anyway.
};
datablock ExplosionData(gorySubExplosion2 : gorySubExplosion1)
{
   debris = boneChunkDebris3;
};
datablock ExplosionData(goryExplosion : gorySubExplosion1)
{
   lifeTimeMS = 500;

   particleEmitter = goreEmitter;
   particleDensity = 45;
   particleRadius  = 2.5;

   debris = boneChunkDebris;
   debrisNum = 6;

   soundProfile = goryExplosionSound;

   emitter[0] = goreEmitter;
   emitter[1] = bigBloodEmitter;
   emitter[2] = smallBloodEmitter;

   subExplosion[0] = gorySubExplosion1;
   subExplosion[1] = gorySubExplosion2;

   uiName = "Gory Explosion";
};
datablock ExplosionData(goryDeathExplosion : deathExplosion)
{
   particleEmitter = goreEmitter;
   particleDensity = 40;
   particleRadius = 1.5;
   emitter[0] = bigBloodEmitter;
   emitter[1] = smallBloodEmitter;
   emitter[2] = goreEmitter;
   lifetimeMS = 500;
   offset = 0.5;
   lightStartRadius = 0;
   lightEndRadius = 0;
};
datablock projectileData(goryDeathExplosionProjectile : deathProjectile)
{
   explosion = goryDeathExplosion;
};
deathProjectile.explosion = "";

datablock ProjectileData(goryExplosionProjectile)
{
   projectileShapeName = "base/data/shapes/empty.dts";
   directDamage     = 10;
   directDamageType = $DamageType::Default; //Damagetype default actually does no damage
   radiusDamageType = $DamageType::Default;
   impactImpulse    = 10;
   verticalImpulse  = 10;
   explosion        = goryExplosion;

   brickExplosionRadius            = 0;
   brickExplosionImpact            = false; 
   brickExplosionForce             = 0;
   brickExplosionMaxVolume         = 0;
   brickExplosionMaxVolumeFloating = 0;

   muzzleVelocity   = 1;
   velInheritFactor = 1;

   lifetime         = 10;
   bounceElasticity = 0;
   bounceFriction   = 0;
   isBallistic    = false;
   explodeOnDeath = true;
   hasLight       = false;

   uiName = "Gory Explosion";
};

datablock ShapeBaseImageData(BloodPainLowImage : painLowImage) { stateEmitter[1] = "smallBloodEmitter"; };
datablock ShapeBaseImageData(BloodPainMidImage : painMidImage) { stateEmitter[1] = "bigBloodEmitter"; };
datablock ShapeBaseImageData(BloodPainHighImage : painHighImage) { stateEmitter[1] = "goreEmitter"; };

package BLOODYPAIN
{
   function Player::emote(%this,%image)
   {
      if(getSubStr(%image,0,7) $= "painLow")
         %image = BloodPainLowImage;
      if(getSubStr(%image,0,7) $= "painMid")
         %image = BloodPainMidImage;
      if(getSubStr(%image,0,7) $= "painHig")
         %image = BloodPainHighImage;
      Parent::emote(%this,%image);
   }
};
if(isPackage(newPain) == false)
{
   activatePackage(BLOODYPAIN);
}
else
{
   error("Chrono's \"New Pain\" add-on detected - not using new pain effects.");
}

datablock ShapeBaseImageData(BloodyImage : playerTeleportImage)
{
   stateTimeoutValue[1] = 10;
   stateEmitter[1]      = bigBloodEmitter;
   stateEmitterTime[1]  = 10;
};
function BloodyImage::onDone(%this, %obj, %slot)
{
   %obj.unMountImage(0);
}

package GORYDEATH
{
   function armor::onDisabled(%data, %obj, %enabled)
   {
      //only do gory death if run over or splatted
      if(%obj.lastDamageType != $DamageType::Vehicle &&
         %obj.lastDamageType != $DamageType::Impact && 
         %obj.lastDamageType != $DamageType::SharkHoleBite)
      {
         Parent::onDisabled(%data, %obj, %enabled);
         return;
      }

      %obj.hideNode("ALL");
         %obj.unHideNode(femchest);
         %obj.unHideNode(pants);
         %obj.unhideNode(larmslim);
         %obj.unhidenode(rarmslim);
         %obj.unHideNode(headskin);
         %obj.setDecalName("AAA-None");
         %obj.setNodeColor("ALL","0.7 0 0 1");
      %obj.unMountImage(0);
      %obj.unMountImage(1);
      %obj.mountImage(BloodyImage,0);
      %proj = new Projectile()
      {
         scale = %obj.getScale();
         dataBlock = goryExplosionProjectile;
         initialVelocity = %obj.getVelocity();
         initialPosition = %obj.getPosition();
         sourceObject = %obj;
         sourceSlot = 0;
         client = %obj.client;
      };
      MissionCleanup.add(%proj);
      %z = getWord(%obj.getScale(),2);
      %obj.schedule(5000, spawnExplosion, goryDeathExplosionProjectile, %z);
      Parent::onDisabled(%data, %obj, %enabled);
   }
};
activatePackage(GORYDEATH);